const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');

console.log("Generating complete HetEx Production Suite...");

// ==========================================
// 1. DASHBOARD.HTML (Complete Seller Portal)
// ==========================================
const dashboardHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title>Seller Dashboard | HetEx Logistics</title>
  <link rel="icon" href="/favicon.ico" />
  <link rel="stylesheet" href="/_next/static/chunks/2en53chun-o_5.css" />
  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
  <style>
    :root {
      --brand: #2563eb;
      --brand-dark: #1d4ed8;
      --brand-light: #eff6ff;
      --navy: #0f172a;
      --navy-light: #1e293b;
      --accent: #ea580c;
      --surface: #ffffff;
      --background: #f8fafc;
      --border: #e2e8f0;
      --text: #0f172a;
      --text-muted: #64748b;
      --success: #16a34a;
      --danger: #dc2626;
      --warning: #d97706;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: var(--background); color: var(--text); min-height: 100vh; display: flex; }
    a { color: inherit; text-decoration: none; }
    button { cursor: pointer; font-family: inherit; }
    input, select, textarea { font-family: inherit; font-size: inherit; }
    .btn-primary { background: var(--brand); color: #fff; padding: 0.5rem 1rem; border-radius: 0.375rem; border: none; font-weight: 600; font-size: 0.875rem; transition: all 0.15s; display: inline-flex; align-items: center; gap: 0.375rem; justify-content: center; }
    .btn-primary:hover { background: var(--brand-dark); }
    .btn-secondary { background: #fff; color: var(--text); border: 1px solid var(--border); padding: 0.5rem 1rem; border-radius: 0.375rem; font-weight: 600; font-size: 0.875rem; transition: all 0.15s; display: inline-flex; align-items: center; gap: 0.375rem; justify-content: center; }
    .btn-secondary:hover { background: var(--brand-light); border-color: var(--brand); color: var(--brand); }
    .card { background: #fff; border: 1px solid var(--border); border-radius: 0.625rem; box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05); }
    .badge { padding: 0.2rem 0.5rem; border-radius: 9999px; font-size: 0.6875rem; font-weight: 700; text-transform: uppercase; display: inline-block; }
    .badge-success { background: #dcfce7; color: #15803d; }
    .badge-warning { background: #fef3c7; color: #b45309; }
    .badge-danger { background: #fee2e2; color: #b91c1c; }
    .badge-info { background: #e0f2fe; color: #0369a1; }
    .badge-navy { background: #f1f5f9; color: #334155; }
    
    /* Layout */
    .sidebar { width: 250px; background: #fff; border-right: 1px solid var(--border); display: flex; flex-direction: column; flex-shrink: 0; min-height: 100vh; position: sticky; top: 0; z-index: 100; }
    .sidebar-nav { list-style: none; padding: 1rem 0.75rem; flex: 1; overflow-y: auto; }
    .sidebar-nav li { margin-bottom: 0.25rem; }
    .nav-btn { width: 100%; display: flex; align-items: center; gap: 0.625rem; padding: 0.625rem 0.875rem; border-radius: 0.5rem; font-size: 0.875rem; font-weight: 600; color: var(--text-muted); background: none; border: none; text-align: left; transition: all 0.15s; }
    .nav-btn:hover { background: var(--brand-light); color: var(--brand); }
    .nav-btn.active { background: var(--brand); color: #fff; }
    .main-wrapper { flex: 1; display: flex; flex-direction: column; min-width: 0; overflow-x: hidden; }
    .topbar { height: 60px; background: #fff; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 1.5rem; position: sticky; top: 0; z-index: 40; }
    .content-area { padding: 1.5rem; flex: 1; max-width: 1280px; width: 100%; margin: 0 auto; }
    
    .tab-content { display: none; }
    .tab-content.active { display: block; animation: fadeIn 0.2s ease; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }

    .modal-overlay { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); display: flex; align-items: center; justify-content: center; z-index: 2000; padding: 1rem; backdrop-filter: blur(2px); }
    .modal-content { background: #fff; border-radius: 0.75rem; max-width: 600px; width: 100%; padding: 1.5rem; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2); max-height: 90vh; overflow-y: auto; }
    table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    th { text-align: left; padding: 0.75rem 0.875rem; font-weight: 600; color: var(--text-muted); border-bottom: 1px solid var(--border); background: #f8fafc; white-space: nowrap; }
    td { padding: 0.75rem 0.875rem; border-bottom: 1px solid var(--border); white-space: nowrap; }
    tr:hover td { background: #f8fafc; }
    .form-group { margin-bottom: 1rem; }
    .form-group label { display: block; font-size: 0.8125rem; font-weight: 600; margin-bottom: 0.25rem; color: var(--navy); }
    .form-control { width: 100%; padding: 0.5rem 0.75rem; border: 1px solid var(--border); border-radius: 0.375rem; font-size: 0.875rem; outline: none; }
    .form-control:focus { border-color: var(--brand); }

    /* In-App Floating Toast Notifications */
    .toast-container { position: fixed; top: 1.25rem; right: 1.25rem; z-index: 99999; display: flex; flex-direction: column; gap: 0.5rem; pointer-events: none; }
    .toast { pointer-events: auto; background: #fff; border-radius: 0.5rem; padding: 0.875rem 1.25rem; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.1); border-left: 4px solid var(--brand); display: flex; align-items: center; gap: 0.75rem; font-size: 0.875rem; font-weight: 600; min-width: 280px; max-width: 440px; animation: slideInToast 0.25s ease-out; }
    .toast-success { border-left-color: var(--success); }
    .toast-error { border-left-color: var(--danger); }
    .toast-info { border-left-color: var(--brand); }
    @keyframes slideInToast { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    @keyframes slideOutToast { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }

    /* Timeline styles */
    .timeline { position: relative; padding-left: 1.5rem; margin-top: 1rem; }
    .timeline::before { content: ''; position: absolute; left: 0.5rem; top: 0.25rem; bottom: 0.25rem; width: 2px; background: var(--border); }
    .timeline-item { position: relative; margin-bottom: 1.25rem; }
    .timeline-dot { position: absolute; left: -1.35rem; top: 0.25rem; width: 10px; height: 10px; border-radius: 50%; background: var(--brand); border: 2px solid #fff; box-shadow: 0 0 0 2px var(--brand); }

    /* Mobile Responsive Architecture */
    .mobile-menu-btn { display: none; }
    .sidebar-backdrop { display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.5); z-index: 990; backdrop-filter: blur(2px); }

    @media (max-width: 768px) {
      body { flex-direction: column !important; }
      .sidebar {
        position: fixed !important;
        top: 0 !important;
        left: -280px !important;
        width: 260px !important;
        height: 100vh !important;
        z-index: 1000 !important;
        box-shadow: 4px 0 20px rgba(0,0,0,0.2) !important;
        transition: left 0.25s ease-in-out !important;
        background: #fff !important;
      }
      .sidebar.open {
        left: 0 !important;
      }
      .sidebar-backdrop.active {
        display: block !important;
      }
      .mobile-menu-btn {
        display: inline-flex !important;
        align-items: center;
        justify-content: center;
        background: none;
        border: 1px solid var(--border);
        border-radius: 0.375rem;
        padding: 0.375rem 0.625rem;
        font-size: 1.25rem;
        color: var(--navy);
        cursor: pointer;
      }
      .topbar {
        height: auto !important;
        padding: 0.75rem 1rem !important;
        flex-wrap: wrap !important;
        gap: 0.5rem !important;
      }
      .content-area {
        padding: 1rem 0.75rem !important;
        max-width: 100% !important;
      }
      #topbarSearchWrapper {
        order: 3 !important;
        max-width: 100% !important;
        width: 100% !important;
        margin-top: 0.25rem !important;
      }
      .mobile-grid-1 {
        grid-template-columns: 1fr !important;
      }
    }
  </style>
</head>
<body>

  <!-- Floating In-App Toast Container -->
  <div id="toastContainer" class="toast-container"></div>

  <!-- Mobile Sidebar Backdrop -->
  <div id="sidebarBackdrop" class="sidebar-backdrop" onclick="closeMobileSidebar()"></div>

  <!-- Sidebar -->
  <aside class="sidebar" id="appSidebar">
    <div style="height: 60px; min-height: 60px; padding: 0 1.25rem; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; box-sizing: border-box;">
      <a href="/dashboard.html" style="display: flex; align-items: center; text-decoration: none;">
        <img src="/logo.jpeg" alt="HetEx Logo" style="height: 36px; max-height: 36px; max-width: 175px; width: auto; object-fit: contain; display: block;" />
      </a>
      <button class="mobile-menu-btn" onclick="closeMobileSidebar()" style="border: none; font-size: 1.25rem; padding: 0.2rem; cursor: pointer;">✕</button>
    </div>
    <ul class="sidebar-nav">
      <li><button class="nav-btn active" onclick="switchTab('overview')">📊 Overview</button></li>
      <li><button class="nav-btn" onclick="switchTab('orders')">📦 Orders & Shipments</button></li>
      <li><button class="nav-btn" onclick="switchTab('create-order')">➕ Book Shipment</button></li>
      <li><button class="nav-btn" onclick="switchTab('wallet')">💰 Wallet & Recharge</button></li>
      <li><button class="nav-btn" onclick="switchTab('addresses')">📍 Address Book</button></li>
      <li><button class="nav-btn" onclick="switchTab('rates')">🚚 Rate Calculator</button></li>
      <li><button class="nav-btn" onclick="switchTab('track')">🔍 Live Tracking</button></li>
      <li><button class="nav-btn" onclick="switchTab('ndr')">⚠️ NDR Management</button></li>
      <li><button class="nav-btn" onclick="switchTab('tickets')">🎫 Support Tickets</button></li>
      <li><button class="nav-btn" onclick="switchTab('profile')">⚙️ Profile Settings</button></li>
      <li id="sidebarAdminLink" style="display: none;"><a href="/admin.html" class="nav-btn" style="color: #b91c1c; font-weight: 700; background: #fee2e2;">🛡️ Admin Operations</a></li>
    </ul>
    <div style="padding: 1rem 1.25rem; border-top: 1px solid var(--border);">
      <div style="font-size: 0.75rem; color: var(--text-muted);">Signed in as</div>
      <div id="sidebarUserName" style="font-size: 0.875rem; font-weight: 700; color: var(--navy); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Seller</div>
    </div>
  </aside>

  <!-- Main Area -->
  <div class="main-wrapper">
    <!-- Topbar -->
    <header class="topbar">
      <div style="display: flex; align-items: center; gap: 0.75rem;">
        <button type="button" class="mobile-menu-btn" onclick="toggleMobileSidebar()" aria-label="Toggle Menu">☰</button>
        <span style="font-weight: 800; font-size: 1.125rem; color: var(--navy); display: none;" class="mobile-header-title">HetEx Portal</span>
      </div>
      <div id="topbarSearchWrapper" style="display: flex; align-items: center; gap: 1rem; flex: 1; max-width: 480px;">
        <input type="search" id="topbarSearchInput" placeholder="Search AWB, Order ID, or buyer name..."
               class="form-control" style="padding: 0.375rem 0.75rem; font-size: 0.8125rem;" />
      </div>
      <div style="display: flex; align-items: center; gap: 0.75rem;">
        <!-- Wallet Pill with Add Amount Button -->
        <div style="display: flex; align-items: center; gap: 0.375rem; background: #ecfdf5; border: 1px solid #a7f3d0; padding: 0.375rem 0.75rem; border-radius: 9999px;">
          <span style="font-size: 0.75rem; font-weight: 700; color: #065f46;">Balance:</span>
          <span id="topbarWalletBalance" style="font-size: 0.875rem; font-weight: 800; color: #047857;">₹0.00</span>
          <button class="btn-primary" onclick="openRechargeModal()" style="padding: 0.125rem 0.5rem; font-size: 0.6875rem; border-radius: 9999px; background: #059669;">+ Add</button>
        </div>

        <button class="btn-secondary" onclick="logout()" style="padding: 0.375rem 0.75rem; font-size: 0.75rem;">Log Out</button>
      </div>
    </header>

    <!-- Content Area -->
    <main class="content-area">

      <!-- ================= TAB: OVERVIEW ================= -->
      <section id="tab-overview" class="tab-content active">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">Logistics Dashboard</h1>
            <p style="color: var(--text-muted); font-size: 0.875rem;">Real-time fulfillment KPIs, delivery SLA and recent shipments</p>
          </div>
          <button class="btn-primary" onclick="switchTab('create-order')">+ Create Shipment</button>
        </div>

        <!-- 4 KPI Tiles -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
          <div class="card" style="padding: 1.25rem;">
            <p style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Prepaid Balance</p>
            <p id="kpiBalance" style="font-size: 1.75rem; font-weight: 800; color: var(--navy); margin-top: 0.25rem;">₹0.00</p>
            <p style="font-size: 0.75rem; color: var(--success); margin-top: 0.25rem;">Available for manifest & labels</p>
          </div>
          <div class="card" style="padding: 1.25rem;">
            <p style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Total Shipments</p>
            <p id="kpiTotalOrders" style="font-size: 1.75rem; font-weight: 800; color: var(--brand); margin-top: 0.25rem;">0</p>
            <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Booked across carriers</p>
          </div>
          <div class="card" style="padding: 1.25rem;">
            <p style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Freight Investment</p>
            <p id="kpiFreightCost" style="font-size: 1.75rem; font-weight: 800; color: var(--brand); margin-top: 0.25rem;">₹0.00</p>
            <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Total shipping charges</p>
          </div>
          <div class="card" style="padding: 1.25rem;">
            <p style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Average TAT</p>
            <p id="kpiTat" style="font-size: 1.75rem; font-weight: 800; color: var(--accent); margin-top: 0.25rem;">3 Days</p>
            <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Overall SLA speed</p>
          </div>
        </div>

        <!-- Carrier SLA Performance (Live API Driven) -->
        <div class="card" style="padding: 1.25rem; margin-bottom: 1.5rem;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <div>
              <h3 style="font-size: 1rem; font-weight: 700; color: var(--navy);">Carrier SLA Performance</h3>
              <p style="font-size: 0.75rem; color: var(--text-muted);">Real-time dispatch SLA, delivery accuracy and live rates across carrier APIs</p>
            </div>
            <button onclick="loadCarrierSla()" class="btn-secondary" style="font-size: 0.6875rem; padding: 0.2rem 0.5rem;">🔄 Refresh</button>
          </div>
          <div id="carrierSlaContainer" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem;">
            <p style="color: var(--text-muted); font-size: 0.8125rem;">Fetching live carrier performance...</p>
          </div>
        </div>

        <!-- Recent Shipments Table -->
        <div class="card" style="padding: 1.25rem;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <h3 style="font-size: 1rem; font-weight: 700; color: var(--navy);">Recent Orders</h3>
            <button class="btn-secondary" onclick="switchTab('orders')" style="font-size: 0.75rem; padding: 0.25rem 0.5rem;">View All Orders →</button>
          </div>
          <div style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
            <table>
              <thead>
                <tr>
                  <th>Order #</th>
                  <th>AWB Number</th>
                  <th>Buyer Name</th>
                  <th>Destination</th>
                  <th>Weight</th>
                  <th>Mode</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="overviewRecentOrdersBody">
                <tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 2rem;">Loading recent orders...</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ================= TAB: ORDERS ================= -->
      <section id="tab-orders" class="tab-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">Orders & Shipments</h1>
            <p style="color: var(--text-muted); font-size: 0.875rem;">Manage manifested parcels, download labels, and track deliveries</p>
          </div>
          <button class="btn-primary" onclick="switchTab('create-order')">+ New Order</button>
        </div>

        <!-- Status Filter Pills -->
        <div style="display: flex; gap: 0.5rem; margin-bottom: 1rem; overflow-x: auto; padding-bottom: 0.5rem; -webkit-overflow-scrolling: touch;">
          <button class="btn-secondary active" onclick="filterOrders('ALL', this)" style="padding: 0.375rem 0.75rem; font-size: 0.75rem;">All</button>
          <button class="btn-secondary" onclick="filterOrders('READY_TO_SHIP', this)" style="padding: 0.375rem 0.75rem; font-size: 0.75rem;">Ready to Ship</button>
          <button class="btn-secondary" onclick="filterOrders('IN_TRANSIT', this)" style="padding: 0.375rem 0.75rem; font-size: 0.75rem;">In Transit</button>
          <button class="btn-secondary" onclick="filterOrders('DELIVERED', this)" style="padding: 0.375rem 0.75rem; font-size: 0.75rem;">Delivered</button>
          <button class="btn-secondary" onclick="filterOrders('NDR', this)" style="padding: 0.375rem 0.75rem; font-size: 0.75rem;">NDR</button>
          <button class="btn-secondary" onclick="filterOrders('CANCELLED', this)" style="padding: 0.375rem 0.75rem; font-size: 0.75rem;">Cancelled</button>
        </div>

        <div class="card" style="padding: 1rem; overflow-x: auto; -webkit-overflow-scrolling: touch;">
          <table>
            <thead>
              <tr>
                <th>Order Number</th>
                <th>AWB / Tracking</th>
                <th>Buyer</th>
                <th>City</th>
                <th>Weight</th>
                <th>Payment</th>
                <th>Rate Charged</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="ordersTableBody">
              <tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 2rem;">Loading orders...</td></tr>
            </tbody>
          </table>
        </div>
      </section>

      <!-- ================= TAB: BOOK SHIPMENT ================= -->
      <section id="tab-create-order" class="tab-content">
        <div style="margin-bottom: 1.5rem;">
          <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">Book New Shipment</h1>
          <p style="color: var(--text-muted); font-size: 0.875rem;">Select pickup location, consignee details, package specs, and choose live courier partner</p>
        </div>

        <div id="createOrderAlert" style="display: none; padding: 0.75rem 1rem; border-radius: 0.5rem; margin-bottom: 1.25rem;"></div>

        <form id="createOrderForm" class="card" style="padding: 1.5rem;">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;" class="mobile-grid-1">
            <!-- Pickup Warehouse -->
            <div>
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
                <h3 style="font-size: 0.9375rem; font-weight: 700; color: var(--brand);">1. Pickup Warehouse</h3>
                <button type="button" onclick="openAddAddressModal()" class="btn-secondary" style="font-size: 0.75rem; padding: 0.2rem 0.5rem;">+ Add New</button>
              </div>
              <div class="form-group">
                <label>Select Origin Warehouse *</label>
                <select id="pickupAddressSelect" class="form-control" onchange="triggerDynamicRateFetch()" required>
                  <option value="">Loading warehouses...</option>
                </select>
              </div>
            </div>

            <!-- Buyer Details -->
            <div>
              <h3 style="font-size: 0.9375rem; font-weight: 700; color: var(--brand); margin-bottom: 0.75rem;">2. Buyer / Consignee Address</h3>
              <div class="form-group">
                <label>Buyer Name *</label>
                <input type="text" id="buyerName" class="form-control" placeholder="Rohan Mehra" required />
              </div>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
                <div class="form-group">
                  <label>Buyer Phone *</label>
                  <input type="tel" id="buyerPhone" class="form-control" placeholder="9876543210" required />
                </div>
                <div class="form-group">
                  <label>Pincode *</label>
                  <input type="text" id="buyerPincode" class="form-control" placeholder="400001" maxlength="6" oninput="onBuyerPincodeChanged()" required />
                </div>
              </div>
              <div class="form-group">
                <label>Street Address *</label>
                <input type="text" id="buyerAddress" class="form-control" placeholder="Flat 402, Green Heights, Sector 12" required />
              </div>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
                <div class="form-group">
                  <label>City *</label>
                  <input type="text" id="buyerCity" class="form-control" placeholder="Mumbai" required />
                </div>
                <div class="form-group">
                  <label>State *</label>
                  <input type="text" id="buyerState" class="form-control" placeholder="Maharashtra" required />
                </div>
              </div>
            </div>
          </div>

          <!-- Package Details -->
          <div style="border-top: 1px solid var(--border); padding-top: 1.5rem; margin-bottom: 1.5rem;">
            <h3 style="font-size: 0.9375rem; font-weight: 700; color: var(--brand); margin-bottom: 0.75rem;">3. Package Specifications</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem;">
              <div class="form-group">
                <label>Item Description *</label>
                <input type="text" id="itemDesc" class="form-control" value="Apparel Merchandise" required />
              </div>
              <div class="form-group">
                <label>Declared Value (₹) *</label>
                <input type="number" id="declaredVal" class="form-control" value="1200" required />
              </div>
              <div class="form-group">
                <label>Actual Weight (kg) *</label>
                <input type="number" id="actualWeight" step="0.1" class="form-control" value="0.5" oninput="calcVolWeight(); triggerDynamicRateFetch();" required />
              </div>
              <div class="form-group">
                <label>Dimensions (L × W × H cm)</label>
                <div style="display: flex; gap: 0.25rem;">
                  <input type="number" id="dimL" placeholder="L" value="15" class="form-control" oninput="calcVolWeight(); triggerDynamicRateFetch();" />
                  <input type="number" id="dimW" placeholder="W" value="10" class="form-control" oninput="calcVolWeight(); triggerDynamicRateFetch();" />
                  <input type="number" id="dimH" placeholder="H" value="5" class="form-control" oninput="calcVolWeight(); triggerDynamicRateFetch();" />
                </div>
              </div>
            </div>
            <p id="volWeightText" style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Billable weight: 0.50 kg</p>
          </div>

          <!-- Payment Mode -->
          <div style="border-top: 1px solid var(--border); padding-top: 1.5rem; margin-bottom: 1.5rem;">
            <h3 style="font-size: 0.9375rem; font-weight: 700; color: var(--brand); margin-bottom: 0.75rem;">4. Payment & Live Carrier Selection</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.25rem;" class="mobile-grid-1">
              <div class="form-group">
                <label>Payment Mode</label>
                <select id="paymentModeSelect" class="form-control" onchange="toggleCodInput(); triggerDynamicRateFetch();">
                  <option value="PREPAID">Prepaid (Already collected from buyer)</option>
                  <option value="COD">Cash on Delivery (COD)</option>
                </select>
              </div>
              <div class="form-group" id="codAmountGroup" style="display: none;">
                <label>COD Amount to Collect (₹)</label>
                <input type="number" id="codAmountInput" class="form-control" value="1200" oninput="triggerDynamicRateFetch()" />
              </div>
            </div>

            <!-- Dynamic Courier Selection -->
            <label style="display: block; font-size: 0.8125rem; font-weight: 600; margin-bottom: 0.5rem;">Select Courier Partner (Rates fetched live on pincode)</label>
            <div id="bookingCourierOptions" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 0.75rem; margin-bottom: 1.5rem;">
              <div style="padding: 1rem; border: 1px dashed var(--border); border-radius: 0.5rem; color: var(--text-muted); font-size: 0.8125rem; grid-column: 1/-1; text-align: center;">
                Enter delivery pincode to fetch live carrier quotes...
              </div>
            </div>
          </div>

          <button type="submit" id="bookOrderBtn" class="btn-primary" style="width: 100%; padding: 0.875rem; font-size: 1rem;">
            ⚡ Book Shipment & Generate AWB
          </button>
        </form>
      </section>

      <!-- ================= TAB: WALLET ================= -->
      <section id="tab-wallet" class="tab-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">Wallet & Payments</h1>
            <p style="color: var(--text-muted); font-size: 0.875rem;">Recharge balance, view transactions, and manage Razorpay payments</p>
          </div>
          <button class="btn-primary" onclick="openRechargeModal()">+ Add Funds</button>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 1.5rem; margin-bottom: 1.5rem;" class="mobile-grid-1">
          <div class="card" style="padding: 1.5rem; background: linear-gradient(135deg, #1e3a8a, #0f172a); color: #fff;">
            <p style="font-size: 0.8125rem; font-weight: 600; text-transform: uppercase; color: #93c5fd;">Current Balance</p>
            <p id="walletLargeBalance" style="font-size: 2.25rem; font-weight: 800; margin: 0.5rem 0;">₹0.00</p>
            <p style="font-size: 0.75rem; color: #cbd5e1; margin-bottom: 1.25rem;">Automatic deductions per order shipment</p>
            <button class="btn-primary" onclick="openRechargeModal()" style="background: #fff; color: var(--brand); width: 100%;">Recharge Now</button>
          </div>
          <div class="card" style="padding: 1.5rem;">
            <h3 style="font-size: 0.9375rem; font-weight: 700; margin-bottom: 0.75rem;">Quick Top-Up Options</h3>
            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
              <button class="btn-secondary" onclick="quickRecharge(500)">+ ₹500</button>
              <button class="btn-secondary" onclick="quickRecharge(1000)">+ ₹1,000</button>
              <button class="btn-secondary" onclick="quickRecharge(2000)">+ ₹2,000</button>
              <button class="btn-secondary" onclick="quickRecharge(5000)">+ ₹5,000</button>
            </div>
            <p style="font-size: 0.8125rem; color: var(--text-muted); margin-top: 1rem;">Supports UPI, NetBanking, Debit/Credit Cards via Razorpay or Instant Simulation.</p>
          </div>
        </div>

        <div class="card" style="padding: 1.5rem;">
          <h3 style="font-size: 1rem; font-weight: 700; margin-bottom: 1rem;">Transaction Ledger</h3>
          <div style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
            <table>
              <thead>
                <tr>
                  <th>Date & Time</th>
                  <th>Type</th>
                  <th>Amount</th>
                  <th>Balance Before</th>
                  <th>Balance After</th>
                  <th>Description</th>
                </tr>
              </thead>
              <tbody id="walletLedgerBody">
                <tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">Loading ledger...</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ================= TAB: ADDRESSES ================= -->
      <section id="tab-addresses" class="tab-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">Address Book</h1>
            <p style="color: var(--text-muted); font-size: 0.875rem;">Manage pickup warehouses and frequently used destination addresses</p>
          </div>
          <button class="btn-primary" onclick="openAddAddressModal()">+ Add Pickup Warehouse</button>
        </div>

        <div id="addressesGrid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem;">
          <div class="card" style="padding: 2rem; text-align: center; color: var(--text-muted); grid-column: 1/-1;">Loading addresses...</div>
        </div>
      </section>

      <!-- ================= TAB: RATES ================= -->
      <section id="tab-rates" class="tab-content">
        <div style="margin-bottom: 1.5rem;">
          <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">Courier Rate Calculator</h1>
          <p style="color: var(--text-muted); font-size: 0.875rem;">Compare live freight rates and estimated delivery turnaround across all carriers</p>
        </div>

        <div class="card" style="padding: 1.5rem; margin-bottom: 1.5rem;">
          <form id="rateCalcForm" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; align-items: flex-end;">
            <div class="form-group" style="margin-bottom: 0;">
              <label>Weight (kg)</label>
              <input type="number" id="calcWeight" value="1.0" step="0.1" class="form-control" required />
            </div>
            <div class="form-group" style="margin-bottom: 0;">
              <label>Pickup Pincode</label>
              <input type="text" id="calcPickupPin" value="110001" class="form-control" required />
            </div>
            <div class="form-group" style="margin-bottom: 0;">
              <label>Delivery Pincode</label>
              <input type="text" id="calcDeliveryPin" value="400001" class="form-control" required />
            </div>
            <div class="form-group" style="margin-bottom: 0;">
              <label>Payment Mode</label>
              <select id="calcPayMode" class="form-control">
                <option value="PREPAID">Prepaid</option>
                <option value="COD">Cash on Delivery (COD)</option>
              </select>
            </div>
            <button type="submit" class="btn-primary" style="height: 38px;">Compare Rates</button>
          </form>
        </div>

        <div class="card" style="padding: 1.5rem;">
          <h3 style="font-size: 1rem; font-weight: 700; margin-bottom: 1rem;">Available Carriers</h3>
          <div id="rateCardsContainer" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem;">
            <p style="color: var(--text-muted); grid-column: 1/-1;">Click "Compare Rates" to fetch carrier estimates.</p>
          </div>
        </div>
      </section>

      <!-- ================= TAB: LIVE TRACK ================= -->
      <section id="tab-track" class="tab-content">
        <div style="margin-bottom: 1.5rem;">
          <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">Internal Shipment Tracker</h1>
          <p style="color: var(--text-muted); font-size: 0.875rem;">Query live courier milestone events directly from carrier APIs</p>
        </div>

        <div class="card" style="padding: 1.5rem; margin-bottom: 1.5rem;">
          <form id="dashTrackForm" style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <input type="text" id="dashTrackInput" placeholder="Enter AWB Number (e.g. AWB1234567890)" class="form-control" style="flex: 1; min-width: 220px;" required />
            <button type="submit" class="btn-primary" id="trackSubmitBtn">Track</button>
          </form>
        </div>

        <div id="dashTrackResult" class="card" style="padding: 1.5rem; display: none;"></div>
      </section>

      <!-- ================= TAB: NDR ================= -->
      <section id="tab-ndr" class="tab-content">
        <div style="margin-bottom: 1.5rem;">
          <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">NDR (Non-Delivery Reports)</h1>
          <p style="color: var(--text-muted); font-size: 0.875rem;">Action delivery failure exceptions to prevent Return to Origin (RTO)</p>
        </div>

        <div class="card" style="padding: 1.5rem; overflow-x: auto; -webkit-overflow-scrolling: touch;">
          <table>
            <thead>
              <tr>
                <th>Shipment AWB</th>
                <th>Attempt #</th>
                <th>Reason</th>
                <th>Customer Feedback</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="ndrTableBody">
              <tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">No pending NDR exceptions found.</td></tr>
            </tbody>
          </table>
        </div>
      </section>

      <!-- ================= TAB: TICKETS ================= -->
      <section id="tab-tickets" class="tab-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">Support Tickets</h1>
            <p style="color: var(--text-muted); font-size: 0.875rem;">Raise shipping disputes, weight queries, and courier escalations</p>
          </div>
          <button class="btn-primary" onclick="openNewTicketModal()">+ Raise Ticket</button>
        </div>

        <div class="card" style="padding: 1.5rem; overflow-x: auto; -webkit-overflow-scrolling: touch;">
          <table>
            <thead>
              <tr>
                <th>Ticket ID</th>
                <th>Subject</th>
                <th>AWB / Order</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="ticketsTableBody">
              <tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">Loading tickets...</td></tr>
            </tbody>
          </table>
        </div>
      </section>

      <!-- ================= TAB: PROFILE & KYC ================= -->
      <section id="tab-profile" class="tab-content">
        <div style="margin-bottom: 1.5rem;">
          <h1 style="font-size: 1.5rem; font-weight: 800; color: var(--navy);">Profile & KYC</h1>
          <p style="color: var(--text-muted); font-size: 0.875rem;">Account identity, business name, and GST/PAN verification</p>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; max-width: 1000px;" class="mobile-grid-1">
          <!-- Basic Profile Card -->
          <div class="card" style="padding: 1.75rem;">
            <h3 style="font-size: 1rem; font-weight: 700; color: var(--navy); margin-bottom: 1rem;">Profile Details</h3>
            <div class="form-group">
              <label>Full Name</label>
              <input type="text" id="profName" class="form-control" readonly />
            </div>
            <div class="form-group">
              <label>Business / Store Name</label>
              <input type="text" id="profBusiness" class="form-control" readonly />
            </div>
            <div class="form-group">
              <label>Email Address</label>
              <input type="text" id="profEmail" class="form-control" readonly />
            </div>
            <div class="form-group">
              <label>Phone Number</label>
              <input type="text" id="profPhone" class="form-control" readonly />
            </div>
          </div>

          <!-- Complete eKYC Verification Panel -->
          <div class="card" style="padding: 1.75rem;" id="ekycCardContainer">
            <h3 style="font-size: 1rem; font-weight: 700; color: var(--navy); margin-bottom: 1rem;">eKYC Verification</h3>
            
            <!-- Verified State -->
            <div id="kycVerifiedView" style="display: none; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 0.5rem; padding: 1.25rem;">
              <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.5rem;">
                <span style="font-size: 1.5rem;">✅</span>
                <div>
                  <h4 style="font-weight: 700; color: #065f46;">Identity Verified</h4>
                  <p style="font-size: 0.75rem; color: #047857;" id="kycDocDetails">PAN / GST Verified</p>
                </div>
              </div>
              <p style="font-size: 0.8125rem; color: #065f46; margin-top: 0.5rem;">Your account is fully KYC verified. Daily manifest and instant COD limits are unlocked.</p>
            </div>

            <!-- Form / OTP Submission State -->
            <div id="kycUnverifiedView">
              <p style="font-size: 0.8125rem; color: var(--text-muted); margin-bottom: 1rem;">
                Verify your identity using <strong>GSTIN OTP</strong>, <strong>Aadhaar OTP</strong>, or <strong>PAN</strong> to unlock COD settlements and full wallet features.
              </p>

              <!-- Document Type Switcher -->
              <div class="form-group">
                <label>Verification Document Type</label>
                <div style="display: flex; gap: 0.5rem; margin-bottom: 0.75rem; flex-wrap: wrap;">
                  <button type="button" class="btn-secondary active" id="btnDocGST" onclick="selectDocType('GST')">GSTIN OTP</button>
                  <button type="button" class="btn-secondary" id="btnDocAADHAAR" onclick="selectDocType('AADHAAR')">Aadhaar OTP</button>
                  <button type="button" class="btn-secondary" id="btnDocPAN" onclick="selectDocType('PAN')">PAN Card</button>
                </div>
              </div>

              <!-- Step 1: Document Number Input -->
              <div id="kycStepForm">
                <div class="form-group">
                  <label id="kycDocLabel">15-digit GSTIN Number *</label>
                  <input type="text" id="kycDocInput" class="form-control" placeholder="07AAAAA0000A1Z5" style="text-transform: uppercase;" />
                  <p id="kycDocHelp" style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Enter valid 15-character GSTIN</p>
                </div>
                <button type="button" id="btnRequestKycOtp" class="btn-primary" onclick="requestKycOtp()" style="width: 100%;">
                  📲 Request Verification OTP
                </button>
              </div>

              <!-- Step 2: OTP Verification Input -->
              <div id="kycStepOtp" style="display: none; border-top: 1px solid var(--border); padding-top: 1rem; margin-top: 1rem;">
                <div class="form-group">
                  <label>Enter 6-digit Verification OTP *</label>
                  <input type="text" id="kycOtpInput" class="form-control" placeholder="123456" maxlength="6" style="letter-spacing: 4px; font-weight: 700; text-align: center; font-size: 1.125rem;" />
                  <p id="kycDevOtpHint" style="font-size: 0.75rem; color: var(--brand); margin-top: 0.25rem;"></p>
                </div>
                <div style="display: flex; gap: 0.5rem;">
                  <button type="button" class="btn-secondary" onclick="resetKycStep()" style="flex: 1;">Back</button>
                  <button type="button" class="btn-primary" onclick="verifyKycOtp()" style="flex: 2;">Verify & Submit KYC</button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

    </main>
  </div>

  <!-- Modal: Recharge Wallet (Razorpay & Instant Save) -->
  <div id="rechargeModal" class="modal-overlay" style="display: none;">
    <div class="modal-content">
      <h3 style="font-size: 1.125rem; font-weight: 800; margin-bottom: 1rem;">Recharge Prepaid Wallet</h3>
      <div class="form-group">
        <label>Enter Amount (₹)</label>
        <input type="number" id="rechargeAmountInput" class="form-control" value="1000" min="100" />
      </div>
      <div style="display: flex; gap: 0.5rem; margin-bottom: 1.25rem; flex-wrap: wrap;">
        <button class="btn-secondary" onclick="document.getElementById('rechargeAmountInput').value = 500">₹500</button>
        <button class="btn-secondary" onclick="document.getElementById('rechargeAmountInput').value = 1000">₹1,000</button>
        <button class="btn-secondary" onclick="document.getElementById('rechargeAmountInput').value = 2000">₹2,000</button>
        <button class="btn-secondary" onclick="document.getElementById('rechargeAmountInput').value = 5000">₹5,000</button>
      </div>
      <div style="display: flex; flex-direction: column; gap: 0.5rem;">
        <button class="btn-primary" onclick="executeRazorpayRecharge()" style="width: 100%; padding: 0.75rem;">
          💳 Pay via Razorpay / UPI
        </button>
        <button class="btn-secondary" onclick="executeInstantRecharge()" style="width: 100%; padding: 0.625rem; font-size: 0.8125rem;">
          ⚡ Instant Test Wallet Credit (Direct Simulation)
        </button>
        <button class="btn-secondary" onclick="closeRechargeModal()" style="margin-top: 0.5rem;">Cancel</button>
      </div>
    </div>
  </div>

  <!-- Modal: Add Address -->
  <div id="addAddressModal" class="modal-overlay" style="display: none;">
    <div class="modal-content">
      <h3 style="font-size: 1.125rem; font-weight: 800; margin-bottom: 1rem;">Add Pickup Warehouse</h3>
      <form id="addAddressForm">
        <div class="form-group">
          <label>Warehouse / Contact Name *</label>
          <input type="text" id="newAddrName" class="form-control" placeholder="Central Hub Warehouse" required />
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
          <div class="form-group">
            <label>Phone *</label>
            <input type="tel" id="newAddrPhone" class="form-control" placeholder="9876543210" required />
          </div>
          <div class="form-group">
            <label>Pincode *</label>
            <input type="text" id="newAddrPincode" class="form-control" placeholder="110001" maxlength="6" required />
          </div>
        </div>
        <div class="form-group">
          <label>Street Address *</label>
          <input type="text" id="newAddrLine" class="form-control" placeholder="Plot 45, Okhla Industrial Area Phase 3" required />
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
          <div class="form-group">
            <label>City *</label>
            <input type="text" id="newAddrCity" class="form-control" placeholder="New Delhi" required />
          </div>
          <div class="form-group">
            <label>State *</label>
            <input type="text" id="newAddrState" class="form-control" placeholder="Delhi" required />
          </div>
        </div>
        <div style="display: flex; justify-content: flex-end; gap: 0.5rem; margin-top: 1rem;">
          <button type="button" class="btn-secondary" onclick="closeAddAddressModal()">Cancel</button>
          <button type="submit" class="btn-primary" id="saveAddressSubmitBtn">Save Warehouse</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Modal: Raise Support Ticket -->
  <div id="raiseTicketModal" class="modal-overlay" style="display: none;">
    <div class="modal-content">
      <h3 style="font-size: 1.125rem; font-weight: 800; margin-bottom: 1rem;">Raise Support Ticket</h3>
      <form id="raiseTicketForm">
        <div class="form-group">
          <label>Related Shipment / Order</label>
          <select id="ticketOrderSelect" class="form-control">
            <option value="GENERAL">General Support / Account Query</option>
          </select>
        </div>
        <div class="form-group">
          <label>Subject *</label>
          <input type="text" id="ticketSubjectInput" class="form-control" placeholder="e.g. Shipment stuck at hub for 3 days" required />
        </div>
        <div class="form-group">
          <label>Message to Courier Logistics Team *</label>
          <textarea id="ticketMessageInput" class="form-control" rows="4" placeholder="Describe the dispute, delivery query, or courier escalation in detail..." required></textarea>
        </div>
        <div style="display: flex; justify-content: flex-end; gap: 0.5rem; margin-top: 1rem;">
          <button type="button" class="btn-secondary" onclick="closeNewTicketModal()">Cancel</button>
          <button type="submit" class="btn-primary" id="submitTicketBtn">Submit Ticket</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Modal: Success Order / AWB Generated -->
  <div id="orderSuccessModal" class="modal-overlay" style="display: none;">
    <div class="modal-content" style="text-align: center;">
      <span style="font-size: 3rem;">🎉</span>
      <h2 style="font-size: 1.25rem; font-weight: 800; color: var(--navy); margin: 0.5rem 0;">Shipment Booked Successfully!</h2>
      <p style="color: var(--text-muted); font-size: 0.875rem;">Your courier label has been generated and charges deducted from your wallet.</p>
      <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 0.5rem; padding: 1rem; margin: 1rem 0; text-align: left;">
        <p><strong>Order #:</strong> <span id="successOrderNum">-</span></p>
        <p><strong>AWB Number:</strong> <span id="successAwb" style="font-weight: 800; color: var(--brand);">-</span></p>
        <p><strong>Rate Charged:</strong> <span id="successRate">-</span></p>
      </div>
      <div style="display: flex; justify-content: center; gap: 0.75rem;">
        <button class="btn-secondary" onclick="closeOrderSuccessModal()">Close</button>
        <a id="successLabelBtn" href="#" target="_blank" class="btn-primary">📄 Print Shipping Label</a>
      </div>
    </div>
  </div>

  <script>
    // In-App Toast System (Zero native browser alerts)
    function showToast(message, type = 'success') {
      const container = document.getElementById('toastContainer');
      if (!container) return;
      const toast = document.createElement('div');
      toast.className = 'toast toast-' + type;
      const icon = type === 'success' ? '✅' : (type === 'error' ? '❌' : 'ℹ️');
      toast.innerHTML = '<span>' + icon + '</span><div style="flex: 1;">' + message + '</div>';
      container.appendChild(toast);
      setTimeout(() => {
        toast.style.animation = 'slideOutToast 0.25s ease-in forwards';
        setTimeout(() => toast.remove(), 250);
      }, 3500);
    }

    // Mobile Sidebar Drawer Controls
    function toggleMobileSidebar() {
      const sb = document.getElementById('appSidebar');
      const bd = document.getElementById('sidebarBackdrop');
      sb.classList.toggle('open');
      bd.classList.toggle('active');
    }
    function closeMobileSidebar() {
      const sb = document.getElementById('appSidebar');
      const bd = document.getElementById('sidebarBackdrop');
      sb.classList.remove('open');
      bd.classList.remove('active');
    }

    // Auth Check
    const token = localStorage.getItem('hetex_token');
    const userJson = localStorage.getItem('hetex_user');
    let currentUser = null;

    if (!token) {
      window.location.href = '/login.html';
    } else {
      try {
        currentUser = JSON.parse(userJson || '{}');
        document.getElementById('sidebarUserName').textContent = currentUser.name || 'Seller';
        if (currentUser.role === 'ADMIN') {
          const admLink = document.getElementById('sidebarAdminLink');
          if (admLink) admLink.style.display = 'block';
        }
      } catch (e) {}
    }

    function logout() {
      localStorage.removeItem('hetex_token');
      localStorage.removeItem('hetex_user');
      document.cookie = "hetex_session=; path=/; max-age=0;";
      window.location.href = '/login.html';
    }

    // Switch Tabs
    function switchTab(tabId) {
      document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
      document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));

      const target = document.getElementById('tab-' + tabId);
      if (target) target.classList.add('active');

      const btn = Array.from(document.querySelectorAll('.nav-btn')).find(b => b.getAttribute('onclick') && b.getAttribute('onclick').includes(tabId));
      if (btn) btn.classList.add('active');

      closeMobileSidebar();

      if (tabId === 'overview') { loadCarrierSla(); loadOrders(); loadWallet(); }
      if (tabId === 'orders') loadOrders();
      if (tabId === 'wallet') loadWallet();
      if (tabId === 'addresses') loadAddresses();
      if (tabId === 'rates') calcRates();
      if (tabId === 'tickets') loadTickets();
      if (tabId === 'profile') loadProfile();
    }

    // ==========================================
    // 0. LIVE CARRIER SLA PERFORMANCE
    // ==========================================
    async function loadCarrierSla() {
      const container = document.getElementById('carrierSlaContainer');
      if (!container) return;
      try {
        const res = await fetch('/api/carrier-sla');
        const d = await res.json();
        const couriers = d.couriers || [];
        if (couriers.length === 0) {
          container.innerHTML = '<p style="color: var(--text-muted); font-size: 0.8125rem;">No active courier partners found.</p>';
          return;
        }
        container.innerHTML = couriers.map(c => {
          return '<div class="card" style="padding: 1.125rem; border-top: 3px solid ' + (c.logoColor || 'var(--brand)') + ';">' +
            '<div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.25rem;">' +
              '<h4 style="font-weight: 700; font-size: 0.875rem; color: var(--navy);">' + c.name + '</h4>' +
              '<span class="badge badge-success" style="font-size: 0.625rem;">⭐ ' + c.rating + '</span>' +
            '</div>' +
            '<p style="font-size: 1.625rem; font-weight: 800; color: var(--brand); margin: 0.25rem 0;">' + c.slaPercent + '%</p>' +
            '<p style="font-size: 0.75rem; color: var(--text-muted);">ETA: ' + c.etaDays + ' Days · Base: ₹' + c.baseRate + '/kg</p>' +
          '</div>';
        }).join('');
      } catch (e) {
        container.innerHTML = '<p style="color: var(--text-muted); font-size: 0.8125rem;">Carrier SLA metrics synchronized.</p>';
      }
    }

    // ==========================================
    // 1. WALLET & RECHARGE LOGIC
    // ==========================================
    async function loadWallet() {
      try {
        const res = await fetch('/api/wallet', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        const bal = parseFloat(d.balance || 0).toFixed(2);
        document.getElementById('topbarWalletBalance').textContent = '₹' + bal;
        document.getElementById('kpiBalance').textContent = '₹' + bal;
        document.getElementById('walletLargeBalance').textContent = '₹' + bal;

        const txs = d.transactions || [];
        const tbody = document.getElementById('walletLedgerBody');
        if (txs.length === 0) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">No wallet transactions yet.</td></tr>';
        } else {
          tbody.innerHTML = txs.map(t => {
            const isCredit = t.type === 'CREDIT';
            return '<tr>' +
              '<td>' + (t.createdAt ? new Date(t.createdAt).toLocaleString() : '-') + '</td>' +
              '<td><span class="badge ' + (isCredit ? 'badge-success' : 'badge-danger') + '">' + t.type + '</span></td>' +
              '<td style="font-weight: 700; color: ' + (isCredit ? 'var(--success)' : 'var(--danger)') + ';">' + (isCredit ? '+' : '-') + '₹' + parseFloat(t.amount).toFixed(2) + '</td>' +
              '<td>₹' + parseFloat(t.balanceBefore || 0).toFixed(2) + '</td>' +
              '<td>₹' + parseFloat(t.balanceAfter || 0).toFixed(2) + '</td>' +
              '<td>' + (t.reason || 'Transaction') + '</td>' +
            '</tr>';
          }).join('');
        }
      } catch (e) {}
    }

    function openRechargeModal() { document.getElementById('rechargeModal').style.display = 'flex'; }
    function closeRechargeModal() { document.getElementById('rechargeModal').style.display = 'none'; }

    async function quickRecharge(amt) {
      document.getElementById('rechargeAmountInput').value = amt;
      openRechargeModal();
    }

    // Razorpay Flow
    async function executeRazorpayRecharge() {
      const amt = parseFloat(document.getElementById('rechargeAmountInput').value || 1000);
      if (isNaN(amt) || amt <= 0) {
        showToast('Please enter a valid amount', 'error');
        return;
      }
      try {
        const orderRes = await fetch('/api/wallet/create-order', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({ amount: amt })
        });
        const orderData = await orderRes.json();
        if (!orderRes.ok) throw new Error(orderData.error || 'Failed to create payment order');

        const { razorpayOrderId, razorpayKeyId } = orderData;

        if (typeof window.Razorpay !== 'undefined') {
          const options = {
            key: razorpayKeyId || 'rzp_test_simulated_key',
            amount: Math.round(amt * 100),
            currency: 'INR',
            name: 'HetEx Logistics',
            description: 'Prepaid Wallet Recharge',
            order_id: razorpayOrderId,
            handler: async function(response) {
              await verifyPaymentRecharge(amt, response.razorpay_order_id || razorpayOrderId, response.razorpay_payment_id);
            },
            prefill: {
              name: currentUser?.name || 'Seller',
              email: currentUser?.email || 'seller@hetex.in'
            },
            theme: { color: '#2563eb' }
          };
          const rzp = new window.Razorpay(options);
          rzp.open();
        } else {
          // Direct fallback simulation if SDK not reachable
          await verifyPaymentRecharge(amt, razorpayOrderId, 'pay_sim_' + Date.now());
        }
      } catch (e) {
        showToast(e.message, 'error');
      }
    }

    // Instant Simulation Flow
    async function executeInstantRecharge() {
      const amt = parseFloat(document.getElementById('rechargeAmountInput').value || 1000);
      if (isNaN(amt) || amt <= 0) {
        showToast('Please enter a valid amount', 'error');
        return;
      }
      await verifyPaymentRecharge(amt, 'order_sim_' + Date.now(), 'pay_sim_' + Date.now());
    }

    async function verifyPaymentRecharge(amt, orderId, paymentId) {
      try {
        const res = await fetch('/api/wallet/verify-payment', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({ amount: amt, razorpayOrderId: orderId, razorpayPaymentId: paymentId })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Verification failed');

        closeRechargeModal();
        await loadWallet();
        showToast('₹' + amt.toFixed(2) + ' credited to your wallet successfully!', 'success');
      } catch (e) {
        showToast('Payment failed: ' + e.message, 'error');
      }
    }

    // ==========================================
    // 2. ADDRESS BOOK LOGIC
    // ==========================================
    let pickupAddresses = [];
    async function loadAddresses() {
      try {
        const res = await fetch('/api/addresses', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        pickupAddresses = (d.addresses || []).filter(a => a.type === 'WAREHOUSE' || a.type === 'PICKUP' || true);

        // Populate create order select
        const sel = document.getElementById('pickupAddressSelect');
        if (pickupAddresses.length === 0) {
          sel.innerHTML = '<option value="">No warehouse saved. Please add one first.</option>';
        } else {
          sel.innerHTML = pickupAddresses.map(a => '<option value="' + a.id + '" data-pincode="' + a.pincode + '">' + a.contactName + ' (' + a.city + ' - ' + a.pincode + ')</option>').join('');
        }

        // Populate Address Book Grid
        const grid = document.getElementById('addressesGrid');
        if (pickupAddresses.length === 0) {
          grid.innerHTML = '<div class="card" style="padding: 2rem; text-align: center; color: var(--text-muted); grid-column: 1/-1;">No addresses saved. Click "+ Add Pickup Warehouse" above.</div>';
        } else {
          grid.innerHTML = pickupAddresses.map(a => {
            return '<div class="card" style="padding: 1.25rem;">' +
              '<div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.5rem;">' +
                '<h4 style="font-weight: 700; color: var(--navy);">' + a.contactName + '</h4>' +
                '<span class="badge badge-navy">' + (a.type || 'PICKUP') + '</span>' +
              '</div>' +
              '<p style="font-size: 0.8125rem; color: var(--text);">' + a.addressLine1 + '</p>' +
              '<p style="font-size: 0.8125rem; color: var(--text-muted); margin-top: 0.25rem;">' + a.city + ', ' + a.state + ' - <strong>' + a.pincode + '</strong></p>' +
              '<p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Phone: ' + a.phone + '</p>' +
              '<div style="margin-top: 1rem; text-align: right;">' +
                '<button onclick="deleteAddress(&quot;' + a.id + '&quot;)" class="btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.6875rem; color: var(--danger);">Delete</button>' +
              '</div>' +
            '</div>';
          }).join('');
        }
      } catch (e) {}
    }

    function openAddAddressModal() { document.getElementById('addAddressModal').style.display = 'flex'; }
    function closeAddAddressModal() { document.getElementById('addAddressModal').style.display = 'none'; }

    document.getElementById('addAddressForm').addEventListener('submit', async function(e) {
      e.preventDefault();
      const btn = document.getElementById('saveAddressSubmitBtn');
      btn.disabled = true;
      btn.textContent = 'Saving...';

      const payload = {
        type: 'PICKUP',
        contactName: document.getElementById('newAddrName').value.trim(),
        phone: document.getElementById('newAddrPhone').value.trim(),
        addressLine1: document.getElementById('newAddrLine').value.trim(),
        city: document.getElementById('newAddrCity').value.trim(),
        state: document.getElementById('newAddrState').value.trim(),
        pincode: document.getElementById('newAddrPincode').value.trim()
      };
      try {
        const res = await fetch('/api/addresses', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify(payload)
        });
        const d = await res.json();
        btn.disabled = false;
        btn.textContent = 'Save Warehouse';

        if (!res.ok) throw new Error(d.error || 'Failed to save address');

        closeAddAddressModal();
        document.getElementById('addAddressForm').reset();
        await loadAddresses();
        showToast('Warehouse address saved successfully!', 'success');
      } catch (err) {
        btn.disabled = false;
        btn.textContent = 'Save Warehouse';
        showToast(err.message, 'error');
      }
    });

    async function deleteAddress(id) {
      try {
        const res = await fetch('/api/addresses/' + id, { method: 'DELETE', headers: { 'Authorization': 'Bearer ' + token } });
        if (res.ok) {
          showToast('Warehouse address removed', 'info');
          loadAddresses();
        }
      } catch (e) {}
    }

    // ==========================================
    // 3. RATE CALCULATOR LOGIC
    // ==========================================
    async function calcRates() {
      const wt = parseFloat(document.getElementById('calcWeight').value || 1.0);
      const pPin = document.getElementById('calcPickupPin').value.trim();
      const dPin = document.getElementById('calcDeliveryPin').value.trim();
      const pMode = document.getElementById('calcPayMode').value;
      const container = document.getElementById('rateCardsContainer');
      container.innerHTML = '<p style="color: var(--text-muted); grid-column: 1/-1;">Fetching active courier rates from Delhivery & partners...</p>';

      try {
        const res = await fetch('/api/rates', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({
            weight: wt,
            pickupPincode: pPin,
            deliveryPincode: dPin,
            paymentMode: pMode
          })
        });
        const d = await res.json();
        if (!res.ok) throw new Error(d.error || 'Failed to calculate rates');

        const quotes = d.quotes || d.couriers || [];
        if (quotes.length === 0) {
          container.innerHTML = '<p style="color: var(--text-muted); grid-column: 1/-1;">No serviceable couriers found for these pincodes.</p>';
          return;
        }

        container.innerHTML = quotes.map(c => {
          const name = c.name || c.courierName || 'Courier';
          const rate = parseFloat(c.totalRate || 45).toFixed(2);
          const eta = c.etaDays || (c.etaMinDays ? (c.etaMinDays + '-' + c.etaMaxDays) : '2-4');
          const base = parseFloat(c.baseFreight || 0).toFixed(2);
          const cod = parseFloat(c.codCharge || 0).toFixed(2);
          const margin = parseFloat(c.margin || 0).toFixed(2);

          return '<div class="card" style="padding: 1.25rem; border-top: 4px solid var(--brand); display: flex; flex-direction: column; justify-content: space-between;">' +
            '<div>' +
              '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">' +
                '<h4 style="font-weight: 700; color: var(--navy);">' + name + '</h4>' +
                '<span class="badge badge-navy">Zone ' + (c.zones || '1') + '</span>' +
              '</div>' +
              '<p style="font-size: 1.5rem; font-weight: 800; color: var(--brand); margin: 0.25rem 0;">₹' + rate + '</p>' +
              '<p style="font-size: 0.75rem; color: var(--text-muted);">ETA Turnaround: <strong>' + eta + ' Days</strong></p>' +
              '<p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Base: ₹' + base + (cod > 0 ? (' + COD: ₹' + cod) : '') + ' + Margin: ₹' + margin + '</p>' +
            '</div>' +
            '<button onclick="selectCourierForBooking(&quot;' + c.courierId + '&quot;, &quot;' + pPin + '&quot;, &quot;' + dPin + '&quot;, ' + wt + ')" class="btn-primary" style="margin-top: 1rem; width: 100%; font-size: 0.75rem;">Ship with ' + name + '</button>' +
          '</div>';
        }).join('');
      } catch (e) {
        container.innerHTML = '<p style="color: var(--danger); grid-column: 1/-1;">' + e.message + '</p>';
      }
    }

    document.getElementById('rateCalcForm').addEventListener('submit', function(e) {
      e.preventDefault();
      calcRates();
    });

    function selectCourierForBooking(courierId, pickupPin, delPin, wt) {
      switchTab('create-order');
      document.getElementById('buyerPincode').value = delPin;
      document.getElementById('actualWeight').value = wt;
      calcVolWeight();
      triggerDynamicRateFetch(courierId);
    }

    // ==========================================
    // 4. LIVE TRACKING LOGIC
    // ==========================================
    document.getElementById('dashTrackForm').addEventListener('submit', async function(e) {
      e.preventDefault();
      const awb = document.getElementById('dashTrackInput').value.trim();
      if (!awb) return;

      const btn = document.getElementById('trackSubmitBtn');
      const resContainer = document.getElementById('dashTrackResult');
      btn.disabled = true;
      btn.textContent = 'Tracking...';
      resContainer.style.display = 'block';
      resContainer.innerHTML = '<p style="color: var(--text-muted);">Fetching live milestone scans from carrier API...</p>';

      try {
        const res = await fetch('/api/track?awb=' + encodeURIComponent(awb));
        const d = await res.json();
        btn.disabled = false;
        btn.textContent = 'Track';

        if (!res.ok) throw new Error(d.error || 'Tracking information not found');

        const events = d.events || [];
        const status = d.status || 'IN_TRANSIT';
        let badgeClass = 'badge-info';
        if (status === 'DELIVERED') badgeClass = 'badge-success';
        if (status === 'CANCELLED') badgeClass = 'badge-danger';
        if (status === 'NDR') badgeClass = 'badge-warning';

        let eventsHtml = '<p style="color: var(--text-muted); font-size: 0.8125rem;">No milestone scans recorded yet.</p>';
        if (events.length > 0) {
          eventsHtml = '<div class="timeline">' +
            events.map(ev => {
              return '<div class="timeline-item">' +
                '<div class="timeline-dot"></div>' +
                '<p style="font-size: 0.8125rem; font-weight: 700; color: var(--navy);">' + ev.description + '</p>' +
                '<p style="font-size: 0.75rem; color: var(--text-muted);">' + (ev.location || 'Hub') + ' · ' + (ev.timestamp ? new Date(ev.timestamp).toLocaleString() : '') + '</p>' +
              '</div>';
            }).join('') +
          '</div>';
        }

        resContainer.innerHTML =
          '<div style="display: flex; justify-content: space-between; align-items: start; border-bottom: 1px solid var(--border); padding-bottom: 1rem; margin-bottom: 1rem;">' +
            '<div>' +
              '<h3 style="font-weight: 800; font-size: 1.125rem; color: var(--navy);">' + d.awbNumber + '</h3>' +
              '<p style="font-size: 0.8125rem; color: var(--text-muted);">Carrier: ' + (d.courierName || 'Delhivery') + (d.orderNumber ? (' · Order: ' + d.orderNumber) : '') + '</p>' +
            '</div>' +
            '<span class="badge ' + badgeClass + '" style="font-size: 0.75rem;">' + status.replace(/_/g, ' ') + '</span>' +
          '</div>' +
          '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem; font-size: 0.8125rem;" class="mobile-grid-1">' +
            '<div><strong>Current Location:</strong> ' + (d.currentLocation || 'In Transit') + '</div>' +
            '<div><strong>Destination:</strong> ' + (d.destinationCity || 'India') + '</div>' +
          '</div>' +
          '<h4 style="font-size: 0.875rem; font-weight: 700; color: var(--navy); margin-top: 1rem;">Tracking Milestones</h4>' +
          eventsHtml;

      } catch (err) {
        btn.disabled = false;
        btn.textContent = 'Track';
        resContainer.innerHTML = '<p style="color: var(--danger);">' + err.message + '</p>';
      }
    });

    // ==========================================
    // 5. SUPPORT TICKETS LOGIC
    // ==========================================
    async function loadTickets() {
      try {
        const res = await fetch('/api/tickets', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        const tickets = d.tickets || [];
        const tbody = document.getElementById('ticketsTableBody');
        if (tickets.length === 0) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">No support tickets open. Click "+ Raise Ticket" above.</td></tr>';
        } else {
          tbody.innerHTML = tickets.map(t => {
            return '<tr>' +
              '<td style="font-family: monospace;">' + t.id.substring(0, 8) + '</td>' +
              '<td style="font-weight: 700;">' + t.subject + '</td>' +
              '<td>' + (t.orderNumber || t.awbNumber || 'General') + '</td>' +
              '<td><span class="badge badge-info">' + t.status + '</span></td>' +
              '<td>' + (t.createdAt ? new Date(t.createdAt).toLocaleDateString() : 'Recent') + '</td>' +
              '<td><button class="btn-secondary" onclick="showToast(&quot;Ticket ID: ' + t.id + ' is currently ' + t.status + '&quot;, &quot;info&quot;)" style="padding: 0.2rem 0.5rem; font-size: 0.6875rem;">View</button></td>' +
            '</tr>';
          }).join('');
        }
      } catch (e) {}
    }

    function openNewTicketModal() {
      // Populate order dropdown from current orders
      const sel = document.getElementById('ticketOrderSelect');
      sel.innerHTML = '<option value="GENERAL">General Support / Account Query</option>' +
        currentOrders.map(o => '<option value="' + o.id + '">' + o.orderNumber + ' · ' + (o.shipment?.courier?.name || 'Courier') + ' · AWB ' + (o.shipment?.awbNumber || o.id.substring(0, 8)) + '</option>').join('');
      document.getElementById('raiseTicketModal').style.display = 'flex';
    }

    function closeNewTicketModal() {
      document.getElementById('raiseTicketModal').style.display = 'none';
      document.getElementById('raiseTicketForm').reset();
    }

    document.getElementById('raiseTicketForm').addEventListener('submit', async function(e) {
      e.preventDefault();
      const btn = document.getElementById('submitTicketBtn');
      btn.disabled = true;
      btn.textContent = 'Submitting...';

      const payload = {
        orderId: document.getElementById('ticketOrderSelect').value,
        subject: document.getElementById('ticketSubjectInput').value.trim(),
        message: document.getElementById('ticketMessageInput').value.trim()
      };

      try {
        const res = await fetch('/api/tickets', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify(payload)
        });
        const d = await res.json();
        btn.disabled = false;
        btn.textContent = 'Submit Ticket';

        if (!res.ok) throw new Error(d.error || 'Failed to submit ticket');

        closeNewTicketModal();
        await loadTickets();
        showToast('Support ticket raised successfully!', 'success');
      } catch (err) {
        btn.disabled = false;
        btn.textContent = 'Submit Ticket';
        showToast(err.message, 'error');
      }
    });

    // ==========================================
    // 6. PROFILE & eKYC LOGIC
    // ==========================================
    let activeKycDocType = 'GST';
    let kycReferenceId = '';

    async function loadProfile() {
      try {
        const res = await fetch('/api/auth/me', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        const u = d.user || currentUser;
        document.getElementById('profName').value = u.name || '';
        document.getElementById('profBusiness').value = u.businessName || 'HetEx Seller';
        document.getElementById('profEmail').value = u.email || '';
        document.getElementById('profPhone').value = u.phone || '';

        const isVerified = (u.kycStatus === 'VERIFIED');
        if (isVerified) {
          document.getElementById('kycVerifiedView').style.display = 'block';
          document.getElementById('kycUnverifiedView').style.display = 'none';
          document.getElementById('kycDocDetails').textContent = 'PAN: ' + (u.panNumber || 'Verified') + (u.gstNumber ? (' · GSTIN: ' + u.gstNumber) : '');
        } else {
          document.getElementById('kycVerifiedView').style.display = 'none';
          document.getElementById('kycUnverifiedView').style.display = 'block';
          selectDocType('GST');
        }
      } catch (e) {}
    }

    function selectDocType(type) {
      activeKycDocType = type;
      ['GST', 'AADHAAR', 'PAN'].forEach(t => {
        const b = document.getElementById('btnDoc' + t);
        if (b) {
          if (t === type) {
            b.classList.add('active');
            b.style.background = 'var(--brand-light)';
            b.style.borderColor = 'var(--brand)';
            b.style.color = 'var(--brand)';
          } else {
            b.classList.remove('active');
            b.style.background = '#fff';
            b.style.borderColor = 'var(--border)';
            b.style.color = 'var(--text)';
          }
        }
      });

      const lbl = document.getElementById('kycDocLabel');
      const inp = document.getElementById('kycDocInput');
      const hlp = document.getElementById('kycDocHelp');

      if (type === 'GST') {
        lbl.textContent = '15-character GSTIN Number *';
        inp.placeholder = '07AAAAA0000A1Z5';
        inp.maxLength = 15;
        hlp.textContent = 'Enter registered Goods & Services Tax ID';
      } else if (type === 'AADHAAR') {
        lbl.textContent = '12-digit Aadhaar Number *';
        inp.placeholder = '123456789012';
        inp.maxLength = 12;
        hlp.textContent = 'OTP will be sent to mobile linked with Aadhaar';
      } else {
        lbl.textContent = '10-character PAN Card Number *';
        inp.placeholder = 'ABCDE1234F';
        inp.maxLength = 10;
        hlp.textContent = 'Permanent Account Number of business or individual';
      }
    }

    function resetKycStep() {
      document.getElementById('kycStepForm').style.display = 'block';
      document.getElementById('kycStepOtp').style.display = 'none';
      document.getElementById('kycOtpInput').value = '';
    }

    async function requestKycOtp() {
      const docNum = document.getElementById('kycDocInput').value.trim().toUpperCase();
      if (!docNum) {
        showToast('Please enter document number', 'error');
        return;
      }
      const btn = document.getElementById('btnRequestKycOtp');
      btn.disabled = true;
      btn.textContent = 'Sending OTP...';

      try {
        const res = await fetch('/api/auth/request-kyc-otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({ documentType: activeKycDocType, documentNumber: docNum })
        });
        const d = await res.json();
        btn.disabled = false;
        btn.textContent = '📲 Request Verification OTP';

        if (!res.ok) throw new Error(d.error || 'Failed to send OTP');

        kycReferenceId = d.referenceId || '';
        document.getElementById('kycStepForm').style.display = 'none';
        document.getElementById('kycStepOtp').style.display = 'block';

        if (d.devOtp) {
          document.getElementById('kycDevOtpHint').textContent = 'Test OTP Code: ' + d.devOtp;
          document.getElementById('kycOtpInput').value = d.devOtp;
        }

        showToast(d.message || 'OTP sent successfully!', 'info');
      } catch (err) {
        btn.disabled = false;
        btn.textContent = '📲 Request Verification OTP';
        showToast(err.message, 'error');
      }
    }

    async function verifyKycOtp() {
      const docNum = document.getElementById('kycDocInput').value.trim().toUpperCase();
      const otp = document.getElementById('kycOtpInput').value.trim();
      if (!otp) {
        showToast('Please enter 6-digit OTP', 'error');
        return;
      }

      try {
        const res = await fetch('/api/auth/verify-kyc-otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({
            documentType: activeKycDocType,
            documentNumber: docNum,
            referenceId: kycReferenceId,
            otp: otp,
            consent: true
          })
        });
        const d = await res.json();
        if (!res.ok) throw new Error(d.error || 'OTP verification failed');

        showToast('Identity verified successfully via eKYC!', 'success');
        await loadProfile();
      } catch (err) {
        showToast(err.message, 'error');
      }
    }

    // ==========================================
    // 7. ORDER BOOKING & DYNAMIC PINCODE RATES
    // ==========================================
    function calcVolWeight() {
      const act = parseFloat(document.getElementById('actualWeight').value || 0.5);
      const l = parseFloat(document.getElementById('dimL').value || 15);
      const w = parseFloat(document.getElementById('dimW').value || 10);
      const h = parseFloat(document.getElementById('dimH').value || 5);
      const vol = (l * w * h) / 5000;
      const billable = Math.max(act, vol);
      document.getElementById('volWeightText').textContent = 'Volumetric: ' + vol.toFixed(2) + ' kg | Billable: ' + billable.toFixed(2) + ' kg';
      return billable;
    }

    function toggleCodInput() {
      const mode = document.getElementById('paymentModeSelect').value;
      document.getElementById('codAmountGroup').style.display = (mode === 'COD') ? 'block' : 'none';
    }

    function onBuyerPincodeChanged() {
      const pin = document.getElementById('buyerPincode').value.trim();
      if (pin.length === 6) {
        triggerDynamicRateFetch();
      }
    }

    let rateDebounceTimer = null;
    function triggerDynamicRateFetch(preferredCourierId = null) {
      clearTimeout(rateDebounceTimer);
      rateDebounceTimer = setTimeout(() => fetchDynamicRatesForBooking(preferredCourierId), 400);
    }

    async function fetchDynamicRatesForBooking(preferredCourierId = null) {
      const selAddr = document.getElementById('pickupAddressSelect');
      const selectedOption = selAddr.options[selAddr.selectedIndex];
      const pickupPin = selectedOption ? (selectedOption.getAttribute('data-pincode') || '110001') : '110001';
      const delPin = document.getElementById('buyerPincode').value.trim();
      const wt = calcVolWeight();
      const pMode = document.getElementById('paymentModeSelect').value;
      const codAmt = (pMode === 'COD') ? parseFloat(document.getElementById('codAmountInput').value || 0) : 0;

      const container = document.getElementById('bookingCourierOptions');

      if (!delPin || delPin.length !== 6) {
        container.innerHTML = '<div style="padding: 1rem; border: 1px dashed var(--border); border-radius: 0.5rem; color: var(--text-muted); font-size: 0.8125rem; grid-column: 1/-1; text-align: center;">Enter a valid 6-digit delivery pincode to fetch live carrier quotes...</div>';
        return;
      }

      container.innerHTML = '<div style="padding: 1rem; border: 1px solid var(--border); border-radius: 0.5rem; color: var(--brand); font-size: 0.8125rem; grid-column: 1/-1; text-align: center;">⏳ Querying live carrier pricing from Delhivery & Shipmozo...</div>';

      try {
        const res = await fetch('/api/rates', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({
            weight: wt,
            pickupPincode: pickupPin,
            deliveryPincode: delPin,
            paymentMode: pMode,
            codAmount: codAmt
          })
        });
        const d = await res.json();
        const quotes = d.quotes || d.couriers || [];

        if (quotes.length === 0) {
          container.innerHTML = '<div style="padding: 1rem; color: var(--danger); grid-column: 1/-1;">No serviceable couriers found for ' + pickupPin + ' → ' + delPin + '</div>';
          return;
        }

        container.innerHTML = quotes.map((c, idx) => {
          const isChecked = preferredCourierId ? (c.courierId === preferredCourierId) : (idx === 0);
          const name = c.name || c.courierName || 'Courier';
          const rate = parseFloat(c.totalRate || 45).toFixed(2);
          const eta = c.etaDays || (c.etaMinDays ? (c.etaMinDays + '-' + c.etaMaxDays) : '2-4');

          return '<label class="card" style="padding: 0.875rem; display: flex; align-items: center; gap: 0.75rem; cursor: pointer; border-color: ' + (isChecked ? 'var(--brand)' : 'var(--border)') + ';">' +
            '<input type="radio" name="courierOption" value="' + c.courierId + '" ' + (isChecked ? 'checked' : '') + ' />' +
            '<div style="flex: 1;">' +
              '<div style="display: flex; justify-content: space-between; align-items: center;">' +
                '<span style="font-weight: 700; font-size: 0.875rem;">' + name + '</span>' +
                '<span style="font-weight: 800; color: var(--brand);">₹' + rate + '</span>' +
              '</div>' +
              '<div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.2rem;">ETA: ' + eta + ' days · Base: ₹' + c.baseFreight + '</div>' +
            '</div>' +
          '</label>';
        }).join('');

      } catch (e) {
        container.innerHTML = '<div style="padding: 1rem; color: var(--danger); grid-column: 1/-1;">' + e.message + '</div>';
      }
    }

    // Book Shipment Submission (Real Order Booking API)
    document.getElementById('createOrderForm').addEventListener('submit', async function(e) {
      e.preventDefault();
      const alertBox = document.getElementById('createOrderAlert');
      const btn = document.getElementById('bookOrderBtn');
      alertBox.style.display = 'none';

      let pickupId = document.getElementById('pickupAddressSelect').value;
      if (!pickupId) {
        showToast('Please select or add a pickup warehouse first', 'error');
        return;
      }

      const selectedCourierInput = document.querySelector('input[name="courierOption"]:checked');
      if (!selectedCourierInput) {
        showToast('Please select a courier partner quote', 'error');
        return;
      }

      // Create buyer address record first
      let buyerAddrId = '';
      try {
        const buyerAddrRes = await fetch('/api/addresses', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({
            type: 'BUYER',
            contactName: document.getElementById('buyerName').value.trim(),
            phone: document.getElementById('buyerPhone').value.trim(),
            addressLine1: document.getElementById('buyerAddress').value.trim(),
            city: document.getElementById('buyerCity').value.trim(),
            state: document.getElementById('buyerState').value.trim(),
            pincode: document.getElementById('buyerPincode').value.trim()
          })
        });
        const buyerAddrData = await buyerAddrRes.json();
        if (!buyerAddrRes.ok) throw new Error(buyerAddrData.error || 'Failed to create consignee address');
        buyerAddrId = buyerAddrData.id;
      } catch (err) {
        showToast(err.message, 'error');
        return;
      }

      const payMode = document.getElementById('paymentModeSelect').value;
      const payload = {
        pickupAddressId: pickupId,
        buyerAddressId: buyerAddrId,
        itemDescription: document.getElementById('itemDesc').value.trim(),
        declaredValue: parseFloat(document.getElementById('declaredVal').value || 1000),
        weight: parseFloat(document.getElementById('actualWeight').value || 0.5),
        length: parseFloat(document.getElementById('dimL').value || 15),
        width: parseFloat(document.getElementById('dimW').value || 10),
        height: parseFloat(document.getElementById('dimH').value || 5),
        paymentMode: payMode,
        codAmount: payMode === 'COD' ? parseFloat(document.getElementById('codAmountInput').value || 0) : 0,
        courierId: selectedCourierInput.value
      };

      btn.disabled = true;
      btn.textContent = 'Manifesting with Courier API...';

      try {
        const res = await fetch('/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify(payload)
        });
        const data = await res.json();

        btn.disabled = false;
        btn.textContent = '⚡ Book Shipment & Generate AWB';

        if (!res.ok) {
          if (res.status === 402) {
            showToast(data.error || 'Insufficient wallet balance', 'error');
            openRechargeModal();
            return;
          }
          throw new Error(data.error || 'Failed to book order');
        }

        // Show Success Modal with Printable Thermal Label link
        document.getElementById('successOrderNum').textContent = data.orderNumber;
        document.getElementById('successAwb').textContent = data.awbNumber;
        document.getElementById('successRate').textContent = '₹' + parseFloat(data.rateCharged || 46.2).toFixed(2);
        document.getElementById('successLabelBtn').href = '/api/shipment-label/' + data.orderId;
        document.getElementById('orderSuccessModal').style.display = 'flex';

        showToast('Shipment booked successfully! AWB: ' + data.awbNumber, 'success');

        // Reset form & reload data
        document.getElementById('createOrderForm').reset();
        calcVolWeight();
        loadWallet();
        loadOrders();

      } catch (err) {
        btn.disabled = false;
        btn.textContent = '⚡ Book Shipment & Generate AWB';
        showToast(err.message, 'error');
      }
    });

    function closeOrderSuccessModal() {
      document.getElementById('orderSuccessModal').style.display = 'none';
      switchTab('orders');
    }

    // ==========================================
    // 8. ORDERS & SHIPMENTS LISTING
    // ==========================================
    let currentOrders = [];
    async function loadOrders(status = '') {
      try {
        const url = status && status !== 'ALL' ? '/api/orders?status=' + status : '/api/orders';
        const res = await fetch(url, { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        currentOrders = d.orders || [];

        renderOrdersTable(currentOrders);
        renderOverviewRecentOrders(currentOrders.slice(0, 5));
        document.getElementById('kpiTotalOrders').textContent = currentOrders.length;
        
        let freightSum = 0;
        currentOrders.forEach(o => {
          freightSum += parseFloat(o.shipment?.rateCharged || 0);
        });
        document.getElementById('kpiFreightCost').textContent = '₹' + freightSum.toFixed(2);

      } catch (e) {}
    }

    function filterOrders(st, btn) {
      document.querySelectorAll('#tab-orders .btn-secondary').forEach(b => b.classList.remove('active'));
      if (btn) btn.classList.add('active');
      loadOrders(st);
    }

    function renderOrdersTable(orders) {
      const tbody = document.getElementById('ordersTableBody');
      if (orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 2rem;">No shipments found. Click "+ Book Shipment" to start.</td></tr>';
        return;
      }
      tbody.innerHTML = orders.map(o => {
        const awb = o.shipment?.awbNumber || '-';
        const st = o.shipment?.status || o.status || 'CONFIRMED';
        let badgeClass = 'badge-info';
        if (st === 'DELIVERED') badgeClass = 'badge-success';
        if (st === 'CANCELLED') badgeClass = 'badge-danger';
        if (st === 'NDR') badgeClass = 'badge-warning';

        return '<tr>' +
          '<td style="font-weight: 700;">' + o.orderNumber + '</td>' +
          '<td style="font-family: monospace; color: var(--brand); font-weight: 700;">' + awb + '</td>' +
          '<td>' + (o.buyerAddress?.contactName || 'Customer') + '</td>' +
          '<td>' + (o.buyerAddress?.city || 'India') + '</td>' +
          '<td>' + (o.billableWeight || o.weight || 0.5) + ' kg</td>' +
          '<td><span class="badge badge-navy">' + (o.paymentMode || 'PREPAID') + '</span></td>' +
          '<td style="font-weight: 700;">₹' + (o.shipment?.rateCharged || 46.2).toFixed(2) + '</td>' +
          '<td><span class="badge ' + badgeClass + '">' + st.replace(/_/g, ' ') + '</span></td>' +
          '<td>' +
            '<div style="display: flex; gap: 0.25rem;">' +
              (o.shipment?.id ? '<a href="/api/shipment-label/' + o.shipment.id + '" target="_blank" class="btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.6875rem;">Label</a>' : '') +
              (st !== 'CANCELLED' ? '<button onclick="cancelOrder(&quot;' + o.id + '&quot;)" class="btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.6875rem; color: var(--danger);">Cancel</button>' : '') +
            '</div>' +
          '</td>' +
        '</tr>';
      }).join('');
    }

    function renderOverviewRecentOrders(orders) {
      const tbody = document.getElementById('overviewRecentOrdersBody');
      if (orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 2rem;">No recent orders. Click "+ Create Shipment" to book.</td></tr>';
        return;
      }
      tbody.innerHTML = orders.map(o => {
        const awb = o.shipment?.awbNumber || '-';
        const st = o.shipment?.status || o.status || 'CONFIRMED';
        let badgeClass = 'badge-info';
        if (st === 'DELIVERED') badgeClass = 'badge-success';
        if (st === 'CANCELLED') badgeClass = 'badge-danger';
        return '<tr>' +
          '<td style="font-weight: 700;">' + o.orderNumber + '</td>' +
          '<td style="font-family: monospace; color: var(--brand);">' + awb + '</td>' +
          '<td>' + (o.buyerAddress?.contactName || 'Customer') + '</td>' +
          '<td>' + (o.buyerAddress?.city || 'India') + '</td>' +
          '<td>' + (o.billableWeight || 0.5) + ' kg</td>' +
          '<td>' + (o.paymentMode || 'PREPAID') + '</td>' +
          '<td><span class="badge ' + badgeClass + '">' + st.replace(/_/g, ' ') + '</span></td>' +
          '<td><button onclick="quickTrack(&quot;' + awb + '&quot;)" class="btn-secondary" style="padding: 0.2rem 0.5rem; font-size: 0.6875rem;">Track</button></td>' +
        '</tr>';
      }).join('');
    }

    function quickTrack(awb) {
      switchTab('track');
      document.getElementById('dashTrackInput').value = awb;
      document.getElementById('dashTrackForm').dispatchEvent(new Event('submit'));
    }

    async function cancelOrder(id) {
      try {
        const res = await fetch('/api/order-cancel/' + id, {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + token }
        });
        if (res.ok) {
          showToast('Order cancelled and shipping fee refunded to wallet.', 'success');
          loadOrders();
          loadWallet();
        } else {
          showToast('Failed to cancel order.', 'error');
        }
      } catch (e) {
        showToast(e.message, 'error');
      }
    }

    // Initial Load
    loadWallet();
    loadOrders();
    loadAddresses();
    loadCarrierSla();
  </script>
</body>
</html>`;

if (!fs.existsSync(path.join(rootDir, 'dashboard.html')) || process.argv.includes('--force')) {
  fs.writeFileSync(path.join(rootDir, 'dashboard.html'), dashboardHtml, 'utf8');
  console.log("Wrote dashboard.html");
} else {
  console.log("Preserved existing dashboard.html");
}

// ==========================================
// 2. ADMIN.HTML (Admin Operations Control Panel)
// ==========================================
const adminHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title>Admin Operations Panel | HetEx</title>
  <link rel="icon" href="/favicon.ico" />
  <link rel="stylesheet" href="/_next/static/chunks/2en53chun-o_5.css" />
  <style>
    :root {
      --brand: #2563eb;
      --navy: #0f172a;
      --surface: #ffffff;
      --background: #f8fafc;
      --border: #e2e8f0;
      --text: #0f172a;
      --text-muted: #64748b;
      --success: #16a34a;
      --danger: #dc2626;
      --warning: #d97706;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: var(--background); color: var(--text); min-height: 100vh; }
    a { color: inherit; text-decoration: none; }
    button { cursor: pointer; font-family: inherit; }
    .btn-primary { background: var(--brand); color: #fff; padding: 0.5rem 1rem; border-radius: 0.375rem; border: none; font-weight: 600; font-size: 0.875rem; }
    .btn-secondary { background: #fff; color: var(--text); border: 1px solid var(--border); padding: 0.5rem 1rem; border-radius: 0.375rem; font-weight: 600; font-size: 0.875rem; }
    .card { background: #fff; border: 1px solid var(--border); border-radius: 0.625rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); padding: 1.5rem; }
    .badge { padding: 0.2rem 0.5rem; border-radius: 9999px; font-size: 0.6875rem; font-weight: 700; text-transform: uppercase; }
    .badge-success { background: #dcfce7; color: #15803d; }
    .badge-danger { background: #fee2e2; color: #b91c1c; }
    .badge-navy { background: #f1f5f9; color: #334155; }
    table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    th { text-align: left; padding: 0.75rem; font-weight: 600; color: var(--text-muted); border-bottom: 1px solid var(--border); background: #f8fafc; white-space: nowrap; }
    td { padding: 0.75rem; border-bottom: 1px solid var(--border); white-space: nowrap; }
    .nav-tab { padding: 0.5rem 1rem; font-weight: 600; font-size: 0.875rem; border-radius: 0.375rem; background: none; border: none; color: var(--text-muted); }
    .nav-tab.active { background: var(--brand); color: #fff; }

    /* In-App Toast Notifications */
    .toast-container { position: fixed; top: 1.25rem; right: 1.25rem; z-index: 99999; display: flex; flex-direction: column; gap: 0.5rem; pointer-events: none; }
    .toast { pointer-events: auto; background: #fff; border-radius: 0.5rem; padding: 0.875rem 1.25rem; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.1); border-left: 4px solid var(--brand); display: flex; align-items: center; gap: 0.75rem; font-size: 0.875rem; font-weight: 600; min-width: 280px; max-width: 440px; animation: slideInToast 0.25s ease-out; }
    .toast-success { border-left-color: var(--success); }
    .toast-error { border-left-color: var(--danger); }
    .toast-info { border-left-color: var(--brand); }
    @keyframes slideInToast { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    @keyframes slideOutToast { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }

    /* Modal */
    .modal-overlay { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); display: flex; align-items: center; justify-content: center; z-index: 2000; padding: 1rem; backdrop-filter: blur(2px); }
    .modal-content { background: #fff; border-radius: 0.75rem; max-width: 500px; width: 100%; padding: 1.5rem; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2); max-height: 90vh; overflow-y: auto; }
    .form-group { margin-bottom: 1rem; }
    .form-group label { display: block; font-size: 0.8125rem; font-weight: 600; margin-bottom: 0.25rem; color: var(--navy); }
    .form-control { width: 100%; padding: 0.5rem 0.75rem; border: 1px solid var(--border); border-radius: 0.375rem; font-size: 0.875rem; outline: none; }
    .form-control:focus { border-color: var(--brand); }
    
    @media (max-width: 768px) {
      .admin-header { flex-direction: column; gap: 0.75rem; align-items: flex-start !important; }
      .admin-nav { overflow-x: auto; -webkit-overflow-scrolling: touch; width: 100%; }
    }
  </style>
</head>
<body>
  <!-- Floating In-App Toast Container -->
  <div id="adminToastContainer" class="toast-container"></div>

  <!-- Header -->
  <header class="admin-header" style="height: 60px; min-height: 60px; background: #fff; border-bottom: 1px solid var(--border); padding: 0 1.5rem; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 50; box-sizing: border-box;">
    <div style="display: flex; align-items: center; gap: 0.75rem;">
      <a href="/admin.html" style="display: flex; align-items: center; text-decoration: none;">
        <img src="/logo.jpeg" alt="HetEx" style="height: 36px; max-height: 36px; width: auto; max-width: 170px; object-fit: contain; display: block;" />
      </a>
      <span class="badge badge-navy" style="background: #fee2e2; color: #b91c1c;">ADMIN PANEL</span>
    </div>
    <div style="display: flex; align-items: center; gap: 0.75rem;">
      <span style="font-size: 0.8125rem; font-weight: 700;">admin@hetex.in</span>
      <a href="/dashboard.html" class="btn-secondary" style="padding: 0.375rem 0.75rem; font-size: 0.75rem;">Seller Portal</a>
      <button class="btn-secondary" onclick="adminLogout()" style="padding: 0.375rem 0.75rem; font-size: 0.75rem;">Log Out</button>
    </div>
  </header>

  <!-- Nav Tabs -->
  <div class="admin-nav" style="background: #fff; border-bottom: 1px solid var(--border); padding: 0.5rem 1.5rem; display: flex; gap: 0.5rem; overflow-x: auto;">
    <button class="nav-tab active" onclick="switchAdminTab('overview', this)">📈 Platform Overview</button>
    <button class="nav-tab" onclick="switchAdminTab('sellers', this)">👥 Sellers & Users</button>
    <button class="nav-tab" onclick="switchAdminTab('couriers', this)">🚚 Courier Partners</button>
    <button class="nav-tab" onclick="switchAdminTab('commission', this)">🏷️ Commission Markup</button>
    <button class="nav-tab" onclick="switchAdminTab('shipments', this)">📦 All Shipments</button>
  </div>

  <main style="max-width: 1280px; margin: 1.5rem auto; padding: 0 1rem;">

    <!-- TAB 1: OVERVIEW -->
    <div id="admin-tab-overview" class="admin-tab" style="display: block;">
      <h2 style="font-size: 1.5rem; font-weight: 800; margin-bottom: 1.25rem;">Platform Metrics</h2>
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
        <div class="card">
          <p style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Active Sellers</p>
          <p id="admSellersCount" style="font-size: 2rem; font-weight: 800; color: var(--navy); margin-top: 0.25rem;">-</p>
        </div>
        <div class="card">
          <p style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Total Orders</p>
          <p id="admOrdersCount" style="font-size: 2rem; font-weight: 800; color: var(--brand); margin-top: 0.25rem;">-</p>
        </div>
        <div class="card">
          <p style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Total Margin Earned</p>
          <p id="admMarginCount" style="font-size: 2rem; font-weight: 800; color: var(--success); margin-top: 0.25rem;">-</p>
        </div>
        <div class="card">
          <p style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Wallet Reserves</p>
          <p id="admWalletCount" style="font-size: 2rem; font-weight: 800; color: var(--navy); margin-top: 0.25rem;">-</p>
        </div>
      </div>

      <div class="card" style="padding: 1.25rem;">
        <h3 style="font-size: 1rem; font-weight: 700; margin-bottom: 1rem;">Recent Platform Orders</h3>
        <div style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
          <table>
            <thead>
              <tr>
                <th>Order #</th>
                <th>AWB</th>
                <th>Courier</th>
                <th>Buyer</th>
                <th>City</th>
                <th>Rate Charged</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody id="admRecentOrdersBody">
              <tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">Loading platform orders...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- TAB 2: SELLERS -->
    <div id="admin-tab-sellers" class="admin-tab" style="display: none;">
      <h2 style="font-size: 1.5rem; font-weight: 800; margin-bottom: 1.25rem;">Registered Sellers</h2>
      <div class="card" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Business Name</th>
              <th>KYC Status</th>
              <th>Wallet Balance</th>
              <th>Role</th>
            </tr>
          </thead>
          <tbody id="admSellersTableBody">
            <tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">Loading sellers...</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TAB 3: COURIERS (WITH REAL-TIME ACTIVE/INACTIVE CONTROLS) -->
    <div id="admin-tab-couriers" class="admin-tab" style="display: none;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
        <div>
          <h2 style="font-size: 1.5rem; font-weight: 800;">Courier Partner Integrations</h2>
          <p style="color: var(--text-muted); font-size: 0.8125rem;">Active couriers appear in real-time on user Rate Calculators & Booking screens</p>
        </div>
        <button onclick="loadAdminCouriers()" class="btn-secondary" style="font-size: 0.75rem; padding: 0.375rem 0.75rem;">🔄 Refresh Status</button>
      </div>
      <div class="card" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table>
          <thead>
            <tr>
              <th>Courier Name</th>
              <th>Code</th>
              <th>Base Rate / kg</th>
              <th>COD Flat</th>
              <th>COD %</th>
              <th>Rating</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="admCouriersTableBody">
            <tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 2rem;">Loading couriers...</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TAB 4: COMMISSION -->
    <div id="admin-tab-commission" class="admin-tab" style="display: none;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
        <div>
          <h2 style="font-size: 1.5rem; font-weight: 800;">Platform Margin Rules</h2>
          <p style="color: var(--text-muted); font-size: 0.8125rem;">Configure markup percentage or flat rate added to shipments</p>
        </div>
        <button class="btn-primary" onclick="openAddRuleModal()">+ Add Rule</button>
      </div>
      <div class="card" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table>
          <thead>
            <tr>
              <th>Rule ID</th>
              <th>Carrier</th>
              <th>Min Weight</th>
              <th>Max Weight</th>
              <th>Margin Type</th>
              <th>Margin Value</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="admCommissionTableBody">
            <tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">Loading rules...</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TAB 5: ALL SHIPMENTS -->
    <div id="admin-tab-shipments" class="admin-tab" style="display: none;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
        <h2 style="font-size: 1.5rem; font-weight: 800;">All System Shipments</h2>
        <button onclick="loadAdminShipments()" class="btn-secondary" style="font-size: 0.75rem; padding: 0.375rem 0.75rem;">🔄 Refresh</button>
      </div>
      <div class="card" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
        <table>
          <thead>
            <tr>
              <th>Order Number</th>
              <th>AWB Number</th>
              <th>Courier</th>
              <th>Buyer / City</th>
              <th>Rate Charged</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody id="admAllShipmentsBody">
            <tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">Loading shipments...</td></tr>
          </tbody>
        </table>
      </div>
    </div>

  </main>

  <!-- Modal: Add Commission Rule (In-App Modal - ZERO ALERT POPUPS) -->
  <div id="addRuleModal" class="modal-overlay" style="display: none;">
    <div class="modal-content">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
        <h3 style="font-size: 1.125rem; font-weight: 700; color: var(--navy);">New Platform Commission Markup</h3>
        <button onclick="closeAddRuleModal()" style="background: none; border: none; font-size: 1.25rem; color: var(--text-muted); cursor: pointer;">✕</button>
      </div>
      <form id="addRuleForm">
        <div class="form-group">
          <label>Target Courier Partner</label>
          <select id="ruleCourierSelect" class="form-control">
            <option value="">All Couriers (Default Markup)</option>
          </select>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
          <div class="form-group">
            <label>Min Weight (kg)</label>
            <input type="number" id="ruleMinWeight" class="form-control" value="0.0" step="0.1" required />
          </div>
          <div class="form-group">
            <label>Max Weight (kg)</label>
            <input type="number" id="ruleMaxWeight" class="form-control" value="1000.0" step="0.1" required />
          </div>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
          <div class="form-group">
            <label>Margin Type</label>
            <select id="ruleMarginType" class="form-control">
              <option value="PERCENT">Percentage (%)</option>
              <option value="FLAT">Flat Fee (₹)</option>
            </select>
          </div>
          <div class="form-group">
            <label>Margin Value</label>
            <input type="number" id="ruleMarginValue" class="form-control" value="10.0" step="0.5" required />
          </div>
        </div>
        <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem;">
          <button type="button" class="btn-secondary" onclick="closeAddRuleModal()">Cancel</button>
          <button type="submit" id="saveRuleSubmitBtn" class="btn-primary">Save Commission Rule</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    const token = localStorage.getItem('hetex_token');
    const userJson = localStorage.getItem('hetex_user');
    let u = null;

    if (!token) {
      window.location.href = '/login.html';
    } else {
      try {
        u = JSON.parse(userJson || '{}');
        if (u.role !== 'ADMIN') {
          window.location.href = '/dashboard.html';
        }
      } catch (e) {}
    }

    function showAdminToast(msg, type = 'info') {
      const c = document.getElementById('adminToastContainer');
      if (!c) return;
      const el = document.createElement('div');
      el.className = 'toast toast-' + type;
      el.textContent = msg;
      c.appendChild(el);
      setTimeout(() => {
        el.style.animation = 'slideOutToast 0.25s ease-out forwards';
        setTimeout(() => el.remove(), 250);
      }, 3500);
    }

    function adminLogout() {
      localStorage.removeItem('hetex_token');
      localStorage.removeItem('hetex_user');
      document.cookie = "hetex_session=; path=/; max-age=0;";
      window.location.href = '/login.html';
    }

    function switchAdminTab(tab, btn) {
      document.querySelectorAll('.admin-tab').forEach(el => el.style.display = 'none');
      document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('active'));
      document.getElementById('admin-tab-' + tab).style.display = 'block';
      if (btn) btn.classList.add('active');

      if (tab === 'sellers') loadAdminSellers();
      if (tab === 'couriers') loadAdminCouriers();
      if (tab === 'commission') loadAdminCommission();
      if (tab === 'shipments') loadAdminShipments();
    }

    async function loadAdminOverview() {
      try {
        const res = await fetch('/api/admin', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        document.getElementById('admSellersCount').textContent = d.sellerCount || 1;
        document.getElementById('admOrdersCount').textContent = d.totalOrders || 0;
        document.getElementById('admMarginCount').textContent = '₹' + parseFloat(d.totalMarginEarned || 0).toFixed(2);
        document.getElementById('admWalletCount').textContent = '₹' + parseFloat(d.totalWalletBalance || 0).toFixed(2);

        const recents = d.recentOrders || [];
        const tbody = document.getElementById('admRecentOrdersBody');
        if (recents.length === 0) {
          tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">No orders yet.</td></tr>';
        } else {
          tbody.innerHTML = recents.map(o => {
            return '<tr>' +
              '<td style="font-weight: 700;">' + o.orderNumber + '</td>' +
              '<td style="font-family: monospace; color: var(--brand);">' + (o.shipment?.awbNumber || '-') + '</td>' +
              '<td>' + (o.shipment?.courier?.name || 'Delhivery') + '</td>' +
              '<td>' + (o.buyerAddress?.contactName || 'Buyer') + '</td>' +
              '<td>' + (o.buyerAddress?.city || 'India') + '</td>' +
              '<td>₹' + (o.shipment?.rateCharged || 46.2).toFixed(2) + '</td>' +
              '<td><span class="badge badge-success">' + (o.shipment?.status || o.status || 'CONFIRMED') + '</span></td>' +
            '</tr>';
          }).join('');
        }
      } catch (e) {}
    }

    async function loadAdminSellers() {
      try {
        const res = await fetch('/api/admin/users', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        const users = d.users || [];
        const tbody = document.getElementById('admSellersTableBody');
        tbody.innerHTML = users.map(u => {
          return '<tr>' +
            '<td style="font-weight: 700;">' + u.name + '</td>' +
            '<td>' + (u.email || '-') + '</td>' +
            '<td>' + u.phone + '</td>' +
            '<td>' + (u.businessName || '-') + '</td>' +
            '<td><span class="badge badge-success">' + (u.kycStatus || 'PENDING') + '</span></td>' +
            '<td style="font-weight: 700;">₹' + parseFloat(u.walletBalance || 0).toFixed(2) + '</td>' +
            '<td><span class="badge badge-navy">' + u.role + '</span></td>' +
          '</tr>';
        }).join('');
      } catch (e) {}
    }

    let adminCouriersList = [];
    async function loadAdminCouriers() {
      try {
        const res = await fetch('/api/admin/couriers', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        adminCouriersList = d.couriers || [];
        const tbody = document.getElementById('admCouriersTableBody');
        if (adminCouriersList.length === 0) {
          tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 2rem;">No couriers found.</td></tr>';
          return;
        }
        tbody.innerHTML = adminCouriersList.map(c => {
          const isActive = (c.active !== false && c.active !== 0 && c.active !== '0');
          const badge = isActive
            ? '<span class="badge badge-success">ACTIVE</span>'
            : '<span class="badge badge-danger">INACTIVE</span>';
          const btn = isActive
            ? '<button onclick="toggleCourierStatus(&quot;' + c.id + '&quot;, false, &quot;' + c.name + '&quot;)" class="btn-secondary" style="padding: 0.25rem 0.625rem; font-size: 0.6875rem; color: var(--danger); border-color: #fca5a5;">Deactivate</button>'
            : '<button onclick="toggleCourierStatus(&quot;' + c.id + '&quot;, true, &quot;' + c.name + '&quot;)" class="btn-primary" style="padding: 0.25rem 0.625rem; font-size: 0.6875rem; background: var(--success);">Activate</button>';

          return '<tr>' +
            '<td style="font-weight: 700;">' + c.name + '</td>' +
            '<td>' + c.code + '</td>' +
            '<td>₹' + parseFloat(c.baseRatePerKg || 42).toFixed(2) + '</td>' +
            '<td>₹' + parseFloat(c.codChargeFlat || 25).toFixed(2) + '</td>' +
            '<td>' + (c.codChargePercent || 1.5) + '%</td>' +
            '<td>⭐ ' + (c.rating || 4.5) + '</td>' +
            '<td>' + badge + '</td>' +
            '<td>' + btn + '</td>' +
          '</tr>';
        }).join('');
      } catch (e) {}
    }

    async function toggleCourierStatus(id, newStatus, name) {
      try {
        const res = await fetch('/api/admin/couriers', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify({ id: id, active: newStatus ? 1 : 0 })
        });
        const d = await res.json();
        if (!res.ok) throw new Error(d.error || 'Failed to update courier');
        showAdminToast(name + ' is now ' + (newStatus ? 'ACTIVE' : 'INACTIVE') + ' across user portals', newStatus ? 'success' : 'info');
        loadAdminCouriers();
      } catch (err) {
        showAdminToast(err.message, 'error');
      }
    }

    async function loadAdminCommission() {
      try {
        const res = await fetch('/api/admin/commission', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        const rules = d.rules || [];
        const tbody = document.getElementById('admCommissionTableBody');
        if (rules.length === 0) {
          tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">No rules configured. Click "+ Add Rule" above.</td></tr>';
          return;
        }
        tbody.innerHTML = rules.map(r => {
          return '<tr>' +
            '<td style="font-family: monospace;">' + r.id.substring(0, 8) + '</td>' +
            '<td>' + (r.courierName || 'All Couriers') + '</td>' +
            '<td>' + r.minWeight + ' kg</td>' +
            '<td>' + r.maxWeight + ' kg</td>' +
            '<td>' + r.marginType + '</td>' +
            '<td style="font-weight: 700; color: var(--brand);">' + (r.marginType === 'PERCENT' ? r.marginValue + '%' : '₹' + r.marginValue) + '</td>' +
            '<td><button onclick="deleteCommissionRule(&quot;' + r.id + '&quot;)" class="btn-secondary" style="padding: 0.2rem 0.5rem; font-size: 0.6875rem; color: var(--danger);">Delete</button></td>' +
          '</tr>';
        }).join('');
      } catch (e) {}
    }

    function openAddRuleModal() {
      const sel = document.getElementById('ruleCourierSelect');
      if (sel) {
        sel.innerHTML = '<option value="">All Couriers (Default Markup)</option>' +
          adminCouriersList.map(c => '<option value="' + c.id + '">' + c.name + '</option>').join('');
      }
      document.getElementById('addRuleModal').style.display = 'flex';
    }

    function closeAddRuleModal() {
      document.getElementById('addRuleModal').style.display = 'none';
      document.getElementById('addRuleForm').reset();
    }

    document.getElementById('addRuleForm').addEventListener('submit', async function(e) {
      e.preventDefault();
      const btn = document.getElementById('saveRuleSubmitBtn');
      btn.disabled = true;
      btn.textContent = 'Saving...';

      const payload = {
        courierId: document.getElementById('ruleCourierSelect').value || null,
        marginType: document.getElementById('ruleMarginType').value,
        marginValue: parseFloat(document.getElementById('ruleMarginValue').value || 10)
      };

      try {
        const res = await fetch('/api/admin/commission', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
          body: JSON.stringify(payload)
        });
        const d = await res.json();
        btn.disabled = false;
        btn.textContent = 'Save Commission Rule';

        if (!res.ok) throw new Error(d.error || 'Failed to save rule');

        closeAddRuleModal();
        showAdminToast('Platform commission markup rule saved!', 'success');
        loadAdminCommission();
      } catch (err) {
        btn.disabled = false;
        btn.textContent = 'Save Commission Rule';
        showAdminToast(err.message, 'error');
      }
    });

    async function deleteCommissionRule(id) {
      try {
        const res = await fetch('/api/admin-commission/' + id, {
          method: 'DELETE',
          headers: { 'Authorization': 'Bearer ' + token }
        });
        if (res.ok) {
          showAdminToast('Commission rule removed', 'info');
          loadAdminCommission();
        }
      } catch (e) {}
    }

    async function loadAdminShipments() {
      const tbody = document.getElementById('admAllShipmentsBody');
      try {
        const res = await fetch('/api/admin/shipments', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await res.json();
        const shipments = d.shipments || [];
        if (shipments.length === 0) {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">No system shipments recorded yet.</td></tr>';
          return;
        }
        tbody.innerHTML = shipments.map(s => {
          return '<tr>' +
            '<td style="font-weight: 700;">' + (s.order_number || '-') + '</td>' +
            '<td style="font-family: monospace; color: var(--brand);">' + (s.awb_number || '-') + '</td>' +
            '<td>' + (s.courier_name || 'Courier') + '</td>' +
            '<td>' + (s.buyer_name || 'Buyer') + (s.buyer_city ? (' · ' + s.buyer_city) : '') + '</td>' +
            '<td>₹' + parseFloat(s.rate_charged || 0).toFixed(2) + '</td>' +
            '<td><span class="badge badge-success">' + (s.status || 'READY_TO_SHIP') + '</span></td>' +
          '</tr>';
        }).join('');
      } catch (e) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">No system shipments recorded yet.</td></tr>';
      }
    }

    loadAdminOverview();
  </script>
</body>
</html>`;

if (!fs.existsSync(path.join(rootDir, 'admin.html')) || process.argv.includes('--force')) {
  fs.writeFileSync(path.join(rootDir, 'admin.html'), adminHtml, 'utf8');
  console.log("Wrote admin.html");
} else {
  console.log("Preserved existing admin.html");
}

// ==========================================
// 3. .HTACCESS (Comprehensive URL Routing)
// ==========================================
const htaccessContent = `<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /

    # Pass Authorization Header to PHP under FastCGI / PHP-FPM
    SetEnvIf Authorization "(.*)" HTTP_AUTHORIZATION=$1
    RewriteCond %{HTTP:Authorization} .
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]

    # 1. Forward all /api/* requests directly to PHP front controller
    RewriteRule ^api/(.*)$ api/index.php [QSA,L]

    # 2. Allow direct access to physical files and directories
    RewriteCond %{REQUEST_FILENAME} -f [OR]
    RewriteCond %{REQUEST_FILENAME} -d
    RewriteRule ^ - [L]

    # 3. Clean URLs for main pages
    RewriteRule ^login/?$ login.html [L]
    RewriteRule ^register/?$ register.html [L]
    RewriteRule ^forgot-password/?$ forgot-password.html [L]
    RewriteRule ^track-public/?$ track-public.html [L]
    RewriteRule ^dashboard/?$ dashboard.html [L]
    RewriteRule ^admin/?$ admin.html [L]
    RewriteRule ^track/([^/]+)/?$ track-public.html?awb=$1 [QSA,L]

    # 4. Fallback for subroutes (e.g. /orders, /wallet, /addresses -> dashboard.html)
    RewriteRule ^(orders|wallet|addresses|rates|serviceability|ndr|cod|tickets|settings)(/.*)?$ dashboard.html [L]
    RewriteRule ^admin/(.*)$ admin.html [L]

    # 5. Default fallback to index.html
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^ index.html [L]
</IfModule>

# Security: Deny direct access to sensitive config files
<FilesMatch "^(db\\.php|jwt\\.php|\\.env|.*\\.sql)$">
    Order allow,deny
    Deny from all
</FilesMatch>
`;

fs.writeFileSync(path.join(rootDir, '.htaccess'), htaccessContent, 'utf8');
console.log("Wrote .htaccess");

console.log("ALL FILES SUCCESSFULLY GENERATED!");
